import UIKit

@main
class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        _ = DataStore.shared
        let window = UIWindow(frame: UIScreen.main.bounds)
        let home = HomeViewController()
        let nav = UINavigationController(rootViewController: home)
        nav.navigationBar.tintColor = .white
        window.rootViewController = nav
        window.makeKeyAndVisible()
        self.window = window
        SoundManager.shared.startMusic()
        return true
    }
}

// どこからでも使える小さな部品
func makeLabel(_ text: String, size: CGFloat, bold: Bool = false, color: UIColor = .white, align: NSTextAlignment = .left) -> UILabel {
    let l = UILabel()
    l.text = text
    l.font = bold ? UIFont.boldSystemFont(ofSize: size) : UIFont.systemFont(ofSize: size)
    l.textColor = color
    l.textAlignment = align
    l.numberOfLines = 0
    return l
}

func makeButton(_ title: String, bg: UIColor, size: CGFloat = 16) -> UIButton {
    let b = UIButton(type: .system)
    b.setTitle(title, for: .normal)
    b.setTitleColor(.white, for: .normal)
    b.titleLabel?.font = UIFont.boldSystemFont(ofSize: size)
    b.backgroundColor = bg
    b.layer.cornerRadius = 12
    b.contentEdgeInsets = UIEdgeInsets(top: 10, left: 12, bottom: 10, right: 12)
    return b
}

func applyGradient(to view: UIView, top: UIColor, bottom: UIColor) {
    view.layer.sublayers?.removeAll(where: { $0.name == "bgGradient" })
    let g = CAGradientLayer()
    g.name = "bgGradient"
    g.frame = view.bounds
    g.colors = [top.cgColor, bottom.cgColor]
    view.layer.insertSublayer(g, at: 0)
}
