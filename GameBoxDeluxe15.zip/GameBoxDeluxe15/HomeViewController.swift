import UIKit

final class HomeViewController: UIViewController {
    private let coinsLabel = UILabel()
    private let bonusLabel = UILabel()

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "ゲーム箱DX"
        buildUI()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        refreshHeader()
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        applyGradient(to: view, top: DataStore.shared.currentTheme.top, bottom: DataStore.shared.currentTheme.bottom)
    }
    private func refreshHeader() {
        coinsLabel.text = "🪙 \(DataStore.shared.coins)　🎮 \(DataStore.shared.totalPlays) 回プレイ　🏆 \(DataStore.shared.totalWins) 勝"
        if DataStore.shared.dailyBonusReady {
            bonusLabel.text = "🎁 今日のボーナス +50コイン もらいました！"
            DataStore.shared.dailyBonusReady = false
        }
    }

    private func buildUI() {
        let scroll = UIScrollView()
        scroll.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(scroll)
        let stack = UIStackView()
        stack.axis = .vertical
        stack.spacing = 12
        stack.translatesAutoresizingMaskIntoConstraints = false
        scroll.addSubview(stack)
        NSLayoutConstraint.activate([
            scroll.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            scroll.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
            scroll.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scroll.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            stack.topAnchor.constraint(equalTo: scroll.topAnchor, constant: 12),
            stack.bottomAnchor.constraint(equalTo: scroll.bottomAnchor, constant: -12),
            stack.leadingAnchor.constraint(equalTo: scroll.leadingAnchor, constant: 14),
            stack.trailingAnchor.constraint(equalTo: scroll.trailingAnchor, constant: -14),
            stack.widthAnchor.constraint(equalTo: scroll.widthAnchor, constant: -28),
        ])

        stack.addArrangedSubview(makeLabel("🎲 ゲーム箱DX 🎮", size: 34, bold: true, align: .center))
        stack.addArrangedSubview(makeLabel("本物より盛りだくさん！ 全17種類 × 最大7人 × 完全オフライン", size: 13, bold: true, align: .center))
        coinsLabel.font = UIFont.boldSystemFont(ofSize: 15)
        coinsLabel.textColor = .yellow
        coinsLabel.textAlignment = .center
        stack.addArrangedSubview(coinsLabel)
        bonusLabel.font = UIFont.boldSystemFont(ofSize: 13)
        bonusLabel.textColor = .yellow
        bonusLabel.textAlignment = .center
        stack.addArrangedSubview(bonusLabel)

        stack.addArrangedSubview(makeLabel("👨‍👩‍👧‍👦 みんなで最大7人（パス＆プレイ）", size: 18, bold: true))
        for g in allGames where g.category == "party" {
            stack.addArrangedSubview(gameButton(g))
        }
        stack.addArrangedSubview(makeLabel("⚔️ 対戦（CPU／2人）", size: 18, bold: true))
        for g in allGames where g.category == "battle" {
            stack.addArrangedSubview(gameButton(g))
        }
        stack.addArrangedSubview(makeLabel("🧩 ひとりで", size: 18, bold: true))
        for g in allGames where g.category == "solo" {
            stack.addArrangedSubview(gameButton(g))
        }

        stack.addArrangedSubview(makeLabel("📚 その他", size: 18, bold: true))
        let themeB = makeButton("🎨 テーマ＆ショップ", bg: UIColor.black.withAlphaComponent(0.35))
        themeB.addTarget(self, action: #selector(openThemes), for: .touchUpInside)
        let trialB = makeButton("✨ プレミアムお試し（本当の課金なし）", bg: UIColor(red: 0.55, green: 0.25, blue: 0.75, alpha: 1))
        trialB.addTarget(self, action: #selector(openTrial), for: .touchUpInside)
        let statsB = makeButton("📊 記録・実績", bg: UIColor.black.withAlphaComponent(0.35))
        statsB.addTarget(self, action: #selector(openStats), for: .touchUpInside)
        let howB = makeButton("❓ あそびかた（全17種類の説明）", bg: UIColor.black.withAlphaComponent(0.35))
        howB.addTarget(self, action: #selector(openHowTo), for: .touchUpInside)
        let setB = makeButton("⚙️ 設定", bg: UIColor.black.withAlphaComponent(0.35))
        setB.addTarget(self, action: #selector(openSettings), for: .touchUpInside)
        for b in [themeB, trialB, statsB, howB, setB] { stack.addArrangedSubview(b) }
        stack.addArrangedSubview(makeLabel("完全オフライン対応：ネットなしで全部遊べます。本当の課金は一切ありません。", size: 11, align: .center))
        refreshHeader()
    }

    private func gameButton(_ g: GameInfo) -> UIButton {
        let plays = DataStore.shared.plays(for: g.id)
        let suffix = plays > 0 ? "（\(plays)回）" : ""
        let b = makeButton("\(g.icon) \(g.title)\(suffix)", bg: UIColor.black.withAlphaComponent(0.35), size: 16)
        b.contentHorizontalAlignment = .leading
        b.addAction(UIAction { _ in
            SoundManager.shared.click()
            self.openGame(g)
        }, for: .touchUpInside)
        return b
    }

    private func openGame(_ g: GameInfo) {
        switch g.category {
        case "party":
            let sel = PlayerSelectViewController(info: g) { [weak self] count in
                self?.pushPartyGame(g.id, count: count)
            }
            navigationController?.pushViewController(sel, animated: true)
        case "battle":
            switch g.id {
            case "tictactoe": navigationController?.pushViewController(TicTacToeViewController(), animated: true)
            case "reversi": navigationController?.pushViewController(ReversiViewController(), animated: true)
            case "gomoku": navigationController?.pushViewController(GomokuViewController(), animated: true)
            case "blackjack": navigationController?.pushViewController(BlackjackViewController(), animated: true)
            case "highlow": navigationController?.pushViewController(HighLowViewController(), animated: true)
            default: break
            }
        default:
            switch g.id {
            case "p2048": navigationController?.pushViewController(Puzzle2048ViewController(), animated: true)
            case "mines": navigationController?.pushViewController(MinesViewController(), animated: true)
            case "snake": navigationController?.pushViewController(SnakeViewController(), animated: true)
            case "reaction": navigationController?.pushViewController(ReactionViewController(), animated: true)
            case "whack": navigationController?.pushViewController(WhackViewController(), animated: true)
            case "slot": navigationController?.pushViewController(SlotViewController(), animated: true)
            default: break
            }
        }
    }

    private func pushPartyGame(_ id: String, count: Int) {
        let vc: UIViewController
        switch id {
        case "diceRace": vc = DiceRaceViewController(playerCount: count)
        case "janken": vc = JankenViewController(playerCount: count)
        case "memory": vc = MemoryGameViewController(playerCount: count)
        case "numGuess": vc = NumGuessViewController(playerCount: count)
        case "bombPass": vc = BombPassViewController(playerCount: count)
        case "quiz": vc = QuizViewController(playerCount: count)
        default: return
        }
        navigationController?.pushViewController(vc, animated: true)
    }

    @objc private func openThemes() { presentNav(ThemeShopViewController(), title: "テーマ＆ショップ") }
    @objc private func openTrial() { presentNav(TrialStoreViewController(), title: "プレミアムお試し") }
    @objc private func openStats() { presentNav(StatsViewController(), title: "記録・実績") }
    @objc private func openHowTo() { presentNav(HowToViewController(), title: "あそびかた") }
    @objc private func openSettings() { presentNav(SettingsViewController(), title: "設定") }

    private func presentNav(_ vc: UIViewController, title: String) {
        SoundManager.shared.click()
        vc.title = title
        let nav = UINavigationController(rootViewController: vc)
        vc.navigationItem.leftBarButtonItem = UIBarButtonItem(title: "閉じる", style: .plain, target: self, action: #selector(closeModal))
        present(nav, animated: true)
    }
    @objc private func closeModal() { dismiss(animated: true) }
}
