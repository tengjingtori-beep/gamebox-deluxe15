import UIKit

// MARK: - 12) 2048風パズル
final class Puzzle2048ViewController: GameBaseViewController {
    private var board: [[Int]] = []
    private var score = 0
    private var labels: [[UILabel]] = []
    private var over = false
    private var reached2048 = false
    private let scoreLabel = UILabel()

    override func viewDidLoad() {
        super.viewDidLoad()
        gameId = "p2048"
        title = "2048風パズル"
        stack.addArrangedSubview(makeLabel("🔠 2048風パズル", size: 22, bold: true, align: .center))
        stack.addArrangedSubview(makeLabel("同じ数字同士をくっつけて大きくしよう。スワイプでも動かせます。", size: 12, align: .center))
        stack.addArrangedSubview(statusLabel)
        scoreLabel.font = UIFont.boldSystemFont(ofSize: 18)
        scoreLabel.textColor = .yellow
        scoreLabel.textAlignment = .center
        stack.addArrangedSubview(scoreLabel)
        let grid = UIStackView()
        grid.axis = .vertical
        grid.spacing = 6
        for r in 0..<4 {
            var rowLabels: [UILabel] = []
            var rowViews: [UIView] = []
            for _ in 0..<4 {
                let l = UILabel()
                l.font = UIFont.boldSystemFont(ofSize: 20)
                l.textAlignment = .center
                l.textColor = .white
                l.layer.cornerRadius = 8
                l.clipsToBounds = true
                l.heightAnchor.constraint(equalToConstant: 62).isActive = true
                rowLabels.append(l)
                rowViews.append(l)
            }
            labels.append(rowLabels)
            grid.addArrangedSubview(equalRow(rowViews))
        }
        stack.addArrangedSubview(grid)
        let upBtn = makeButton("⬆️", bg: UIColor.black.withAlphaComponent(0.4), size: 22)
        upBtn.addAction(UIAction { [weak self] _ in self?.move(dir: 0) }, for: .touchUpInside)
        let leftBtn = makeButton("⬅️", bg: UIColor.black.withAlphaComponent(0.4), size: 22)
        leftBtn.addAction(UIAction { [weak self] _ in self?.move(dir: 2) }, for: .touchUpInside)
        let downBtn = makeButton("⬇️", bg: UIColor.black.withAlphaComponent(0.4), size: 22)
        downBtn.addAction(UIAction { [weak self] _ in self?.move(dir: 1) }, for: .touchUpInside)
        let rightBtn = makeButton("➡️", bg: UIColor.black.withAlphaComponent(0.4), size: 22)
        rightBtn.addAction(UIAction { [weak self] _ in self?.move(dir: 3) }, for: .touchUpInside)
        stack.addArrangedSubview(equalRow([UIView(), upBtn, UIView()]))
        stack.addArrangedSubview(equalRow([leftBtn, downBtn, rightBtn]))
        for dir in [UISwipeGestureRecognizer.Direction.up, .down, .left, .right] {
            let g = UISwipeGestureRecognizer(target: self, action: #selector(swiped(_:)))
            g.direction = dir
            view.addGestureRecognizer(g)
        }
        addRetryHomeRow { [weak self] in self?.resetGame() }
        resetGame()
    }
    @objc private func swiped(_ g: UISwipeGestureRecognizer) {
        switch g.direction {
        case .up: move(dir: 0)
        case .down: move(dir: 1)
        case .left: move(dir: 2)
        default: move(dir: 3)
        }
    }
    private func resetGame() {
        board = [[Int]](repeating: [Int](repeating: 0, count: 4), count: 4)
        score = 0
        over = false
        reached2048 = false
        spawn(); spawn()
        refresh()
        setStatus("数字を動かしてね")
    }
    private func spawn() {
        var empty: [(Int, Int)] = []
        for r in 0..<4 { for c in 0..<4 { if board[r][c] == 0 { empty.append((r, c)) } } }
        if let cell = empty.randomElement() {
            board[cell.0][cell.1] = Int.random(in: 1...10) == 10 ? 4 : 2
        }
    }
    private func tileColor(_ v: Int) -> UIColor {
        switch v {
        case 0: return UIColor.black.withAlphaComponent(0.25)
        case 2: return UIColor(red: 0.55, green: 0.50, blue: 0.45, alpha: 1)
        case 4: return UIColor(red: 0.65, green: 0.55, blue: 0.40, alpha: 1)
        case 8: return UIColor(red: 0.95, green: 0.55, blue: 0.20, alpha: 1)
        case 16: return UIColor(red: 0.95, green: 0.45, blue: 0.15, alpha: 1)
        case 32: return UIColor(red: 0.90, green: 0.30, blue: 0.20, alpha: 1)
        case 64: return UIColor(red: 0.85, green: 0.20, blue: 0.15, alpha: 1)
        case 128: return UIColor(red: 0.90, green: 0.75, blue: 0.20, alpha: 1)
        case 256: return UIColor(red: 0.85, green: 0.70, blue: 0.15, alpha: 1)
        case 512: return UIColor(red: 0.80, green: 0.65, blue: 0.10, alpha: 1)
        case 1024: return UIColor(red: 0.75, green: 0.60, blue: 0.05, alpha: 1)
        default: return UIColor(red: 0.30, green: 0.60, blue: 0.90, alpha: 1)
        }
    }
    private func refresh() {
        for r in 0..<4 { for c in 0..<4 {
            labels[r][c].text = board[r][c] == 0 ? "" : "\(board[r][c])"
            labels[r][c].backgroundColor = tileColor(board[r][c])
        } }
        scoreLabel.text = "スコア：\(score)　（ベスト：\(DataStore.shared.best(for: "p2048"))）"
    }
    private func slideLine(_ line: [Int]) -> ([Int], Int) {
        let compact = line.filter { $0 != 0 }
        var result: [Int] = []
        var gained = 0
        var i = 0
        while i < compact.count {
            if i + 1 < compact.count && compact[i] == compact[i + 1] {
                let v = compact[i] * 2
                result.append(v)
                gained += v
                i += 2
            } else {
                result.append(compact[i])
                i += 1
            }
        }
        while result.count < 4 { result.append(0) }
        return (result, gained)
    }
    // dir: 0=上 1=下 2=左 3=右
    private func move(dir: Int) {
        if over { return }
        let before = board
        var gained = 0
        if dir == 2 || dir == 3 {
            for r in 0..<4 {
                var line = board[r]
                if dir == 3 { line = Array(line.reversed()) }
                let (newLine, g) = slideLine(line)
                gained += g
                board[r] = dir == 3 ? Array(newLine.reversed()) : newLine
            }
        } else {
            for c in 0..<4 {
                var line = (0..<4).map { board[$0][c] }
                if dir == 1 { line = Array(line.reversed()) }
                let (newLine, g) = slideLine(line)
                gained += g
                let finalLine = dir == 1 ? Array(newLine.reversed()) : newLine
                for r in 0..<4 { board[r][c] = finalLine[r] }
            }
        }
        if board == before { return }
        score += gained
        SoundManager.shared.click()
        spawn()
        refresh()
        DataStore.shared.submitScore(gameId: "p2048", score: score)
        if !reached2048 && board.flatMap({ $0 }).contains(2048) {
            reached2048 = true
            setStatus("🎉 2048達成！まだ続けられるよ")
            SoundManager.shared.win()
        }
        if isGameOver() {
            over = true
            let maxTile = board.flatMap({ $0 }).max() ?? 0
            finishGame(won: maxTile >= 2048, playerCount: 1, titleText: "😢 ゲームオーバー",
                       message: "スコア \(score) 点／最大タイル \(maxTile)") { [weak self] in self?.resetGame() }
        }
    }
    private func isGameOver() -> Bool {
        for r in 0..<4 { for c in 0..<4 {
            if board[r][c] == 0 { return false }
            if c + 1 < 4 && board[r][c] == board[r][c + 1] { return false }
            if r + 1 < 4 && board[r][c] == board[r + 1][c] { return false }
        } }
        return true
    }
}

// MARK: - 13) 地雷探し（9×9・地雷10）
final class MinesViewController: GameBaseViewController {
    private let size = 9
    private let mineCount = 10
    private var mines: Set<Int> = []
    private var counts: [[Int]] = []
    private var revealed: [[Bool]] = []
    private var flagged: [[Bool]] = []
    private var cells: [[UIButton]] = []
    private var flagMode = false
    private var placed = false
    private var over = false
    private var startDate: Date?
    private var timer: Timer?
    private let timeLabel = UILabel()
    private var flagBtn: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        gameId = "mines"
        title = "地雷探し"
        stack.addArrangedSubview(makeLabel("💥 地雷探し（9×9・地雷\(mineCount)個）", size: 22, bold: true, align: .center))
        stack.addArrangedSubview(statusLabel)
        timeLabel.font = UIFont.boldSystemFont(ofSize: 15)
        timeLabel.textColor = .yellow
        timeLabel.textAlignment = .center
        stack.addArrangedSubview(timeLabel)
        flagBtn = makeButton("モード：開ける 👆", bg: UIColor.black.withAlphaComponent(0.4))
        flagBtn.addAction(UIAction { [weak self] _ in
            guard let self = self else { return }
            self.flagMode = !self.flagMode
            self.flagBtn.setTitle(self.flagMode ? "モード：旗 🚩" : "モード：開ける 👆", for: .normal)
            SoundManager.shared.click()
        }, for: .touchUpInside)
        stack.addArrangedSubview(flagBtn)
        let grid = UIStackView()
        grid.axis = .vertical
        grid.spacing = 3
        for r in 0..<size {
            var rowBtns: [UIButton] = []
            var rowCells: [UIButton] = []
            for c in 0..<size {
                let b = makeButton("　", bg: UIColor(red: 0.25, green: 0.45, blue: 0.75, alpha: 1), size: 14)
                let rr = r, cc = c
                b.addAction(UIAction { [weak self] _ in self?.tapCell(rr, cc) }, for: .touchUpInside)
                rowBtns.append(b)
                rowCells.append(b)
            }
            cells.append(rowCells)
            grid.addArrangedSubview(equalRow(rowBtns))
        }
        stack.addArrangedSubview(grid)
        addRetryHomeRow { [weak self] in self?.resetGame() }
        resetGame()
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        timer?.invalidate(); timer = nil
    }
    private func resetGame() {
        timer?.invalidate(); timer = nil
        mines = []
        counts = [[Int]](repeating: [Int](repeating: 0, count: size), count: size)
        revealed = [[Bool]](repeating: [Bool](repeating: false, count: size), count: size)
        flagged = [[Bool]](repeating: [Bool](repeating: false, count: size), count: size)
        placed = false
        over = false
        startDate = nil
        flagMode = false
        flagBtn.setTitle("モード：開ける 👆", for: .normal)
        timeLabel.text = "⏱ 0 秒"
        for r in 0..<size { for c in 0..<size {
            cells[r][c].setTitle("　", for: .normal)
            cells[r][c].backgroundColor = UIColor(red: 0.25, green: 0.45, blue: 0.75, alpha: 1)
        } }
        setStatus("マスをタップして開けてね（最初の1手は安全）")
    }
    private func idx(_ r: Int, _ c: Int) -> Int { r * size + c }
    private func placeMines(safeR: Int, safeC: Int) {
        var s = Set<Int>()
        while s.count < mineCount {
            let v = Int.random(in: 0..<(size * size))
            if v == idx(safeR, safeC) { continue }
            s.insert(v)
        }
        mines = s
        for r in 0..<size { for c in 0..<size {
            var cnt = 0
            for dr in -1...1 { for dc in -1...1 {
                let rr = r + dr, cc = c + dc
                if rr >= 0 && rr < size && cc >= 0 && cc < size && mines.contains(idx(rr, cc)) { cnt += 1 }
            } }
            counts[r][c] = cnt
        } }
        placed = true
        startDate = Date()
        timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { [weak self] _ in
            guard let self = self, let d = self.startDate else { return }
            self.timeLabel.text = "⏱ \(Int(Date().timeIntervalSince(d))) 秒"
        }
    }
    private func tapCell(_ r: Int, _ c: Int) {
        if over || revealed[r][c] { return }
        if flagMode {
            flagged[r][c] = !flagged[r][c]
            cells[r][c].setTitle(flagged[r][c] ? "🚩" : "　", for: .normal)
            SoundManager.shared.click()
            return
        }
        if flagged[r][c] { return }
        if !placed { placeMines(safeR: r, safeC: c) }
        if mines.contains(idx(r, c)) {
            over = true
            timer?.invalidate(); timer = nil
            SoundManager.shared.boom()
            for m in mines {
                cells[m / size][m % size].setTitle("💣", for: .normal)
                cells[m / size][m % size].backgroundColor = UIColor(red: 0.75, green: 0.15, blue: 0.15, alpha: 1)
            }
            finishGame(won: false, playerCount: 1, titleText: "💥 地雷を踏んだ…",
                       message: "もう一回挑戦しよう！") { [weak self] in self?.resetGame() }
            return
        }
        reveal(r, c)
        SoundManager.shared.click()
        checkWin()
    }
    private func reveal(_ r: Int, _ c: Int) {
        if r < 0 || r >= size || c < 0 || c >= size || revealed[r][c] || flagged[r][c] { return }
        revealed[r][c] = true
        cells[r][c].backgroundColor = UIColor.black.withAlphaComponent(0.25)
        cells[r][c].setTitle(counts[r][c] == 0 ? "　" : "\(counts[r][c])", for: .normal)
        if counts[r][c] == 0 {
            for dr in -1...1 { for dc in -1...1 { if dr != 0 || dc != 0 { reveal(r + dr, c + dc) } } }
        }
    }
    private func checkWin() {
        var opened = 0
        for r in 0..<size { for c in 0..<size { if revealed[r][c] { opened += 1 } } }
        if opened == size * size - mineCount {
            over = true
            timer?.invalidate(); timer = nil
            let sec = startDate != nil ? Int(Date().timeIntervalSince(startDate!)) : 0
            DataStore.shared.submitScore(gameId: "mines", score: sec, lowerIsBetter: true)
            finishGame(won: true, playerCount: 1, titleText: "🎉 クリア！",
                       message: "地雷を全部よけた！タイム \(sec) 秒") { [weak self] in self?.resetGame() }
        }
    }
}

// MARK: - 14) スネーク
final class SnakeViewController: GameBaseViewController {
    private let size = 12
    private var snake: [(Int, Int)] = [(6, 6), (6, 5), (6, 4)]
    private var dir = (0, 1)
    private var pendingDir = (0, 1)
    private var food = (3, 3)
    private var cells: [[UIView]] = []
    private var timer: Timer?
    private var over = false
    private let scoreLabel = UILabel()

    override func viewDidLoad() {
        super.viewDidLoad()
        gameId = "snake"
        title = "スネーク"
        stack.addArrangedSubview(makeLabel("🐍 スネーク", size: 22, bold: true, align: .center))
        stack.addArrangedSubview(statusLabel)
        scoreLabel.font = UIFont.boldSystemFont(ofSize: 16)
        scoreLabel.textColor = .yellow
        scoreLabel.textAlignment = .center
        stack.addArrangedSubview(scoreLabel)
        let grid = UIStackView()
        grid.axis = .vertical
        grid.spacing = 2
        for _ in 0..<size {
            var rowViews: [UIView] = []
            var rowCells: [UIView] = []
            for _ in 0..<size {
                let v = UIView()
                v.layer.cornerRadius = 3
                v.heightAnchor.constraint(equalToConstant: 24).isActive = true
                rowViews.append(v)
                rowCells.append(v)
            }
            cells.append(rowCells)
            grid.addArrangedSubview(equalRow(rowViews))
        }
        stack.addArrangedSubview(grid)
        let upBtn = makeButton("⬆️", bg: UIColor.black.withAlphaComponent(0.4), size: 20)
        upBtn.addAction(UIAction { [weak self] _ in self?.setDir(-1, 0) }, for: .touchUpInside)
        let leftBtn = makeButton("⬅️", bg: UIColor.black.withAlphaComponent(0.4), size: 20)
        leftBtn.addAction(UIAction { [weak self] _ in self?.setDir(0, -1) }, for: .touchUpInside)
        let downBtn = makeButton("⬇️", bg: UIColor.black.withAlphaComponent(0.4), size: 20)
        downBtn.addAction(UIAction { [weak self] _ in self?.setDir(1, 0) }, for: .touchUpInside)
        let rightBtn = makeButton("➡️", bg: UIColor.black.withAlphaComponent(0.4), size: 20)
        rightBtn.addAction(UIAction { [weak self] _ in self?.setDir(0, 1) }, for: .touchUpInside)
        stack.addArrangedSubview(equalRow([UIView(), upBtn, UIView()]))
        stack.addArrangedSubview(equalRow([leftBtn, downBtn, rightBtn]))
        for d in [UISwipeGestureRecognizer.Direction.up, .down, .left, .right] {
            let g = UISwipeGestureRecognizer(target: self, action: #selector(swiped(_:)))
            g.direction = d
            view.addGestureRecognizer(g)
        }
        addRetryHomeRow { [weak self] in self?.resetGame() }
        resetGame()
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        timer?.invalidate(); timer = nil
    }
    @objc private func swiped(_ g: UISwipeGestureRecognizer) {
        switch g.direction {
        case .up: setDir(-1, 0)
        case .down: setDir(1, 0)
        case .left: setDir(0, -1)
        default: setDir(0, 1)
        }
    }
    private func setDir(_ dr: Int, _ dc: Int) {
        if dir.0 + dr == 0 && dir.1 + dc == 0 { return } // 逆向き禁止
        pendingDir = (dr, dc)
    }
    private func resetGame() {
        timer?.invalidate(); timer = nil
        snake = [(6, 6), (6, 5), (6, 4)]
        dir = (0, 1); pendingDir = (0, 1)
        over = false
        placeFood()
        render()
        setStatus("🍎を食べて長くなろう！")
        timer = Timer.scheduledTimer(withTimeInterval: 0.22, repeats: true) { [weak self] _ in self?.step() }
    }
    private func placeFood() {
        while true {
            let f = (Int.random(in: 0..<size), Int.random(in: 0..<size))
            if !snake.contains(where: { $0.0 == f.0 && $0.1 == f.1 }) { food = f; return }
        }
    }
    private func render() {
        for r in 0..<size { for c in 0..<size {
            cells[r][c].backgroundColor = UIColor.black.withAlphaComponent(0.25)
        } }
        cells[food.0][food.1].backgroundColor = UIColor(red: 0.90, green: 0.25, blue: 0.20, alpha: 1)
        for (i, s) in snake.enumerated() {
            cells[s.0][s.1].backgroundColor = i == 0 ? UIColor(red: 0.40, green: 0.95, blue: 0.40, alpha: 1) : UIColor(red: 0.15, green: 0.70, blue: 0.30, alpha: 1)
        }
        scoreLabel.text = "長さ：\(snake.count)　スコア：\(snake.count - 3)　（ベスト：\(DataStore.shared.best(for: "snake"))）"
    }
    private func step() {
        if over { return }
        dir = pendingDir
        let head = (snake[0].0 + dir.0, snake[0].1 + dir.1)
        if head.0 < 0 || head.0 >= size || head.1 < 0 || head.1 >= size || snake.contains(where: { $0.0 == head.0 && $0.1 == head.1 }) {
            die()
            return
        }
        snake.insert(head, at: 0)
        if head.0 == food.0 && head.1 == food.1 {
            SoundManager.shared.buy()
            placeFood()
        } else {
            snake.removeLast()
        }
        render()
    }
    private func die() {
        over = true
        timer?.invalidate(); timer = nil
        SoundManager.shared.bad()
        let sc = snake.count - 3
        DataStore.shared.submitScore(gameId: "snake", score: sc)
        finishGame(won: sc >= 10, playerCount: 1, titleText: "😢 ゲームオーバー",
                   message: "スコア \(sc)（食べた🍎の数）") { [weak self] in self?.resetGame() }
    }
}

// MARK: - 15) 反射神経
final class ReactionViewController: GameBaseViewController {
    private enum Phase { case idle, waiting, ready, done }
    private var phase: Phase = .idle
    private var startDate: Date?
    private var timer: Timer?
    private var sessionBest = 0
    private var tries = 0
    private var areaBtn: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        gameId = "reaction"
        title = "反射神経"
        stack.addArrangedSubview(makeLabel("⚡️ 反射神経", size: 22, bold: true, align: .center))
        stack.addArrangedSubview(makeLabel("「待って…」のあと、緑になったらすぐタップ！早すぎると失格。", size: 13, align: .center))
        stack.addArrangedSubview(statusLabel)
        areaBtn = makeButton("▶ ここをタップでスタート", bg: UIColor(red: 0.15, green: 0.45, blue: 0.90, alpha: 1), size: 22)
        areaBtn.heightAnchor.constraint(equalToConstant: 200).isActive = true
        areaBtn.addAction(UIAction { [weak self] _ in self?.areaTapped() }, for: .touchUpInside)
        stack.addArrangedSubview(areaBtn)
        let endBtn = makeButton("🏁 記録して終わる", bg: UIColor.black.withAlphaComponent(0.4))
        endBtn.addAction(UIAction { [weak self] _ in self?.finishSession() }, for: .touchUpInside)
        stack.addArrangedSubview(endBtn)
        addRetryHomeRow { [weak self] in self?.resetGame() }
        resetGame()
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        timer?.invalidate(); timer = nil
    }
    private func resetGame() {
        timer?.invalidate(); timer = nil
        phase = .idle
        sessionBest = 0
        tries = 0
        areaBtn.setTitle("▶ ここをタップでスタート", for: .normal)
        areaBtn.backgroundColor = UIColor(red: 0.15, green: 0.45, blue: 0.90, alpha: 1)
        setStatus("ベスト記録：\(DataStore.shared.best(for: "reaction") > 0 ? "\(DataStore.shared.best(for: "reaction")) ミリ秒" : "まだなし")")
    }
    private func areaTapped() {
        switch phase {
        case .idle, .done:
            phase = .waiting
            areaBtn.setTitle("待って…", for: .normal)
            areaBtn.backgroundColor = UIColor(red: 0.80, green: 0.20, blue: 0.20, alpha: 1)
            setStatus("緑になるまで待って…")
            let delay = Double.random(in: 1.5...4.0)
            timer?.invalidate()
            timer = Timer.scheduledTimer(withTimeInterval: delay, repeats: false) { [weak self] _ in
                guard let self = self, self.phase == .waiting else { return }
                self.phase = .ready
                self.startDate = Date()
                self.areaBtn.setTitle("タップ！", for: .normal)
                self.areaBtn.backgroundColor = UIColor(red: 0.10, green: 0.70, blue: 0.30, alpha: 1)
                SoundManager.shared.click()
            }
        case .waiting:
            timer?.invalidate(); timer = nil
            phase = .idle
            SoundManager.shared.bad()
            areaBtn.setTitle("😱 早すぎ！失格。もう一回", for: .normal)
            areaBtn.backgroundColor = UIColor(red: 0.15, green: 0.45, blue: 0.90, alpha: 1)
            setStatus("フライングは失格！タップで再挑戦")
        case .ready:
            let ms = Int(Date().timeIntervalSince(startDate ?? Date()) * 1000)
            phase = .done
            tries += 1
            if sessionBest == 0 || ms < sessionBest { sessionBest = ms }
            DataStore.shared.submitScore(gameId: "reaction", score: ms, lowerIsBetter: true)
            SoundManager.shared.win()
            SoundManager.shared.haptic()
            areaBtn.setTitle("\(ms) ミリ秒！", for: .normal)
            areaBtn.backgroundColor = UIColor(red: 0.15, green: 0.45, blue: 0.90, alpha: 1)
            setStatus("⚡️ \(ms) ミリ秒！（今日のベスト \(sessionBest)／記録 \(DataStore.shared.best(for: "reaction"))）タップでもう一回")
        }
    }
    private func finishSession() {
        if tries == 0 { setStatus("まず1回タップで測ってね"); return }
        finishGame(won: sessionBest > 0 && sessionBest <= 300, playerCount: 1,
                   titleText: "⚡️ 結果", message: "ベスト \(sessionBest) ミリ秒（\(tries) 回測定）") { [weak self] in self?.resetGame() }
    }
}

// MARK: - 16) もぐらたたき（30秒・9穴）
final class WhackViewController: GameBaseViewController {
    private var holes: [UIButton] = []
    private var moleIdx = -1
    private var score = 0
    private var timeLeft = 30
    private var running = false
    private var countTimer: Timer?
    private var spawnTimer: Timer?
    private let timeLabel = UILabel()
    private var startBtn: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        gameId = "whack"
        title = "もぐらたたき"
        stack.addArrangedSubview(makeLabel("🔨 もぐらたたき（30秒）", size: 22, bold: true, align: .center))
        stack.addArrangedSubview(statusLabel)
        timeLabel.font = UIFont.boldSystemFont(ofSize: 18)
        timeLabel.textColor = .yellow
        timeLabel.textAlignment = .center
        timeLabel.text = "⏱ 30 秒"
        stack.addArrangedSubview(timeLabel)
        let grid = UIStackView()
        grid.axis = .vertical
        grid.spacing = 8
        for r in 0..<3 {
            var rowBtns: [UIButton] = []
            for c in 0..<3 {
                let idx = r * 3 + c
                let b = makeButton("🕳", bg: UIColor(red: 0.45, green: 0.30, blue: 0.15, alpha: 1), size: 30)
                b.addAction(UIAction { [weak self] _ in self?.tapHole(idx) }, for: .touchUpInside)
                holes.append(b)
                rowBtns.append(b)
            }
            grid.addArrangedSubview(equalRow(rowBtns))
        }
        stack.addArrangedSubview(grid)
        startBtn = makeButton("▶ スタート！", bg: UIColor(red: 0.85, green: 0.30, blue: 0.10, alpha: 1), size: 20)
        startBtn.addAction(UIAction { [weak self] _ in self?.startGame() }, for: .touchUpInside)
        stack.addArrangedSubview(startBtn)
        addRetryHomeRow { [weak self] in self?.resetGame() }
        resetGame()
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        countTimer?.invalidate(); spawnTimer?.invalidate()
    }
    private func resetGame() {
        countTimer?.invalidate(); spawnTimer?.invalidate()
        running = false
        score = 0
        timeLeft = 30
        moleIdx = -1
        timeLabel.text = "⏱ 30 秒"
        for h in holes { h.setTitle("🕳", for: .normal) }
        startBtn.isEnabled = true
        setStatus("ベスト：\(DataStore.shared.best(for: "whack")) 匹")
    }
    private func startGame() {
        if running { return }
        running = true
        score = 0
        timeLeft = 30
        startBtn.isEnabled = false
        spawnMole()
        countTimer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { [weak self] _ in
            guard let self = self else { return }
            self.timeLeft -= 1
            self.timeLabel.text = "⏱ \(self.timeLeft) 秒　スコア：\(self.score)"
            if self.timeLeft <= 0 { self.endGame() }
        }
        spawnTimer = Timer.scheduledTimer(withTimeInterval: 0.75, repeats: true) { [weak self] _ in self?.spawnMole() }
        setStatus("🐹をタップ！")
    }
    private func spawnMole() {
        if !running { return }
        if moleIdx >= 0 { holes[moleIdx].setTitle("🕳", for: .normal) }
        moleIdx = Int.random(in: 0..<9)
        holes[moleIdx].setTitle("🐹", for: .normal)
    }
    private func tapHole(_ i: Int) {
        if !running { return }
        if i == moleIdx {
            score += 1
            SoundManager.shared.playCard()
            SoundManager.shared.haptic()
            holes[i].setTitle("💫", for: .normal)
            moleIdx = -1
            setStatus("🎉 ヒット！ スコア：\(score)")
        }
    }
    private func endGame() {
        running = false
        countTimer?.invalidate(); spawnTimer?.invalidate()
        for h in holes { h.setTitle("🕳", for: .normal) }
        DataStore.shared.submitScore(gameId: "whack", score: score)
        finishGame(won: score >= 15, playerCount: 1, titleText: "⏱ 終了！",
                   message: "\(score) 匹たたいた！（ベスト \(DataStore.shared.best(for: "whack"))）") { [weak self] in self?.resetGame() }
    }
}

// MARK: - 17) スロット（コイン消費/獲得・絵柄3つ）
final class SlotViewController: GameBaseViewController {
    private let symbols = ["🍒", "🍋", "🔔", "⭐", "💎", "7️⃣"]
    private let payouts: [String: Int] = ["🍒": 50, "🍋": 80, "🔔": 120, "⭐": 200, "💎": 400, "7️⃣": 770]
    private var reelLabels: [UILabel] = []
    private var spinTimer: Timer?
    private var ticks = 0
    private var sessionNet = 0
    private var spinning = false
    private let coinsLabel = UILabel()
    private var spinBtn: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        gameId = "slot"
        title = "スロット"
        stack.addArrangedSubview(makeLabel("🎰 スロット（賭け10コイン）", size: 22, bold: true, align: .center))
        stack.addArrangedSubview(makeLabel("3つそろうと大当たり！2つそろうと20コイン。コインはゲーム内だけのものです。", size: 12, align: .center))
        stack.addArrangedSubview(statusLabel)
        coinsLabel.font = UIFont.boldSystemFont(ofSize: 18)
        coinsLabel.textColor = .yellow
        coinsLabel.textAlignment = .center
        stack.addArrangedSubview(coinsLabel)
        var views: [UIView] = []
        for _ in 0..<3 {
            let l = UILabel()
            l.font = UIFont.systemFont(ofSize: 52)
            l.textAlignment = .center
            l.text = "🍒"
            l.backgroundColor = UIColor.black.withAlphaComponent(0.30)
            l.layer.cornerRadius = 12
            l.clipsToBounds = true
            l.heightAnchor.constraint(equalToConstant: 84).isActive = true
            reelLabels.append(l)
            views.append(l)
        }
        stack.addArrangedSubview(equalRow(views))
        spinBtn = makeButton("🎰 スピン！（10コイン）", bg: UIColor(red: 0.85, green: 0.30, blue: 0.10, alpha: 1), size: 20)
        spinBtn.addAction(UIAction { [weak self] _ in self?.spin() }, for: .touchUpInside)
        stack.addArrangedSubview(spinBtn)
        stack.addArrangedSubview(makeLabel("当たり表：🍒50／🍋80／🔔120／⭐200／💎400／7️⃣7️⃣7️⃣ 770", size: 12, align: .center))
        let cashBtn = makeButton("🏁 精算して終わる", bg: UIColor.black.withAlphaComponent(0.4))
        cashBtn.addAction(UIAction { [weak self] _ in
            guard let self = self else { return }
            self.finishGame(won: self.sessionNet > 0, playerCount: 1, titleText: "🎰 精算",
                            message: "このセッションの収支：\(self.sessionNet >= 0 ? "+" : "")\(self.sessionNet) コイン") { [weak self] in self?.resetSession() }
        }, for: .touchUpInside)
        stack.addArrangedSubview(cashBtn)
        addRetryHomeRow { [weak self] in self?.resetSession() }
        refreshCoins()
        setStatus("スピンしてね！")
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        spinTimer?.invalidate(); spinTimer = nil
    }
    private func resetSession() {
        sessionNet = 0
        refreshCoins()
        setStatus("新しいセッション。スピンしてね！")
    }
    private func refreshCoins() { coinsLabel.text = "🪙 コイン：\(DataStore.shared.coins)　セッション収支：\(sessionNet >= 0 ? "+" : "")\(sessionNet)" }
    private func spin() {
        if spinning { return }
        if DataStore.shared.coins < 10 {
            let a = UIAlertController(title: "コインが足りません", message: "「プレミアムお試し」でコインを無料入手できます（実際¥0）", preferredStyle: .alert)
            a.addAction(UIAlertAction(title: "お試し画面へ", style: .default) { _ in
                let nav = UINavigationController(rootViewController: TrialStoreViewController())
                self.present(nav, animated: true)
            })
            a.addAction(UIAlertAction(title: "閉じる", style: .cancel))
            present(a, animated: true)
            return
        }
        DataStore.shared.coins -= 10
        sessionNet -= 10
        spinning = true
        spinBtn.isEnabled = false
        ticks = 0
        refreshCoins()
        spinTimer?.invalidate()
        spinTimer = Timer.scheduledTimer(withTimeInterval: 0.07, repeats: true) { [weak self] _ in
            guard let self = self else { return }
            self.ticks += 1
            for l in self.reelLabels { l.text = self.symbols.randomElement() ?? "🍒" }
            SoundManager.shared.click()
            if self.ticks >= 14 { self.stopSpin() }
        }
    }
    private func stopSpin() {
        spinTimer?.invalidate(); spinTimer = nil
        spinning = false
        spinBtn.isEnabled = true
        let result = (0..<3).map { _ in symbols.randomElement() ?? "🍒" }
        for (i, l) in reelLabels.enumerated() { l.text = result[i] }
        var win = 0
        if result[0] == result[1] && result[1] == result[2] {
            win = payouts[result[0]] ?? 50
            setStatus("🎉 大当たり！ \(result[0])×3 で +\(win) コイン！")
            SoundManager.shared.win()
        } else if result[0] == result[1] || result[1] == result[2] || result[0] == result[2] {
            win = 20
            setStatus("✨ 2つそろった！ +20 コイン")
            SoundManager.shared.buy()
        } else {
            setStatus("😢 はずれ… もう一回！")
            SoundManager.shared.bad()
        }
        if win > 0 {
            DataStore.shared.coins += win
            sessionNet += win
        }
        refreshCoins()
    }
}
