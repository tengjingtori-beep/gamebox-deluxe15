import Foundation
import AVFoundation
import UIKit

// 音源ファイルなしで音を合成する（オフライン完結）
final class SoundManager {
    static let shared = SoundManager()
    private var players: [AVAudioPlayer] = []
    private var musicTimer: Timer?
    private var musicStep = 0
    private let melody: [Double] = [523.25, 587.33, 659.25, 783.99, 659.25, 587.33, 523.25, 0,
                                    440.0, 523.25, 587.33, 659.25, 587.33, 523.25, 440.0, 0]

    private func wavData(freq: Double, duration: Double, volume: Float = 0.32, slide: Double = 0) -> Data {
        let sampleRate = 22050.0
        let count = Int(sampleRate * duration)
        var data = Data()
        func appendLE<T: FixedWidthInteger>(_ v: T) { var x = v.littleEndian; withUnsafeBytes(of: &x) { data.append(contentsOf: $0) } }
        let byteRate = UInt32(sampleRate) * 2
        let dataSize = UInt32(count * 2)
        data.append(contentsOf: "RIFF".utf8); appendLE(UInt32(36) + dataSize)
        data.append(contentsOf: "WAVE".utf8)
        data.append(contentsOf: "fmt ".utf8); appendLE(UInt32(16)); appendLE(UInt16(1)); appendLE(UInt16(1))
        appendLE(UInt32(sampleRate)); appendLE(byteRate); appendLE(UInt16(2)); appendLE(UInt16(16))
        data.append(contentsOf: "data".utf8); appendLE(dataSize)
        for i in 0..<count {
            let t = Double(i) / sampleRate
            let f = freq + slide * (t / duration)
            let env = 1.0 - (Double(i) / Double(count)) * 0.7
            let s = sin(2 * Double.pi * f * t) * Double(volume) * env
            appendLE(Int16(max(-1, min(1, s)) * 30000))
        }
        return data
    }

    private func play(freq: Double, duration: Double, slide: Double = 0, volume: Float = 0.32) {
        guard DataStore.shared.soundOn else { return }
        do {
            let p = try AVAudioPlayer(data: wavData(freq: freq, duration: duration, volume: volume, slide: slide))
            p.prepareToPlay(); p.play()
            players.append(p)
            if players.count > 8 { players.removeFirst(players.count - 8) }
        } catch { }
    }

    func click() { play(freq: 840, duration: 0.05, volume: 0.18) }
    func playCard() { play(freq: 500, duration: 0.08, slide: 300) }
    func drawCard() { play(freq: 350, duration: 0.07, slide: 150) }
    func uno() {
        play(freq: 988, duration: 0.1)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.09) { self.play(freq: 1319, duration: 0.16) }
    }
    func win() {
        let notes: [Double] = [523, 659, 784, 1047]
        for (i, n) in notes.enumerated() {
            DispatchQueue.main.asyncAfter(deadline: .now() + Double(i) * 0.13) { self.play(freq: n, duration: 0.18) }
        }
    }
    func bad() { play(freq: 200, duration: 0.25, slide: -60, volume: 0.4) }
    func buy() { play(freq: 1047, duration: 0.1); DispatchQueue.main.asyncAfter(deadline: .now() + 0.09) { self.play(freq: 1568, duration: 0.16) } }
    func flip() { play(freq: 400, duration: 0.15, slide: 700) }
    func boom() { play(freq: 140, duration: 0.3, slide: -60, volume: 0.5) }

    func haptic() {
        guard DataStore.shared.hapticsOn else { return }
        let g = UIImpactFeedbackGenerator(style: .light)
        g.impactOccurred()
    }

    func startMusic() {
        stopMusic()
        guard DataStore.shared.musicOn else { return }
        musicTimer = Timer.scheduledTimer(withTimeInterval: 0.26, repeats: true) { [weak self] _ in
            guard let self = self, DataStore.shared.musicOn else { return }
            let f = self.melody[self.musicStep % self.melody.count]
            self.musicStep += 1
            if f > 0 { self.play(freq: f, duration: 0.24, volume: 0.09) }
        }
    }
    func stopMusic() { musicTimer?.invalidate(); musicTimer = nil }
}
