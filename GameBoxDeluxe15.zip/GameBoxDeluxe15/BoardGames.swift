import UIKit

// MARK: - 7) ○×ゲーム（三目並べ・CPU強さ3段階／2人）
final class TicTacToeViewController: GameBaseViewController {
    private var board: [Int] = [Int](repeating: 0, count: 9) // 1=X(先手) 2=O
    private var turn = 1
    private var over = false
    private var cells: [UIButton] = []
    private let modeSeg = UISegmentedControl(items: ["🤖 CPU対戦", "👥 2人対戦"])
    private let diffSeg = UISegmentedControl(items: ["やさしい", "ふつう", "つよい"])

    override func viewDidLoad() {
        super.viewDidLoad()
        gameId = "tictactoe"
        title = "○×ゲーム"
        stack.addArrangedSubview(makeLabel("⭕️ ○×ゲーム（3つ並べれば勝ち）", size: 22, bold: true, align: .center))
        modeSeg.selectedSegmentIndex = 0
        modeSeg.addAction(UIAction { [weak self] _ in self?.resetGame() }, for: .valueChanged)
        stack.addArrangedSubview(modeSeg)
        diffSeg.selectedSegmentIndex = 1
        diffSeg.addAction(UIAction { [weak self] _ in self?.resetGame() }, for: .valueChanged)
        stack.addArrangedSubview(diffSeg)
        stack.addArrangedSubview(statusLabel)
        for r in 0..<3 {
            var rowBtns: [UIButton] = []
            for c in 0..<3 {
                let idx = r * 3 + c
                let b = makeButton("　", bg: UIColor.black.withAlphaComponent(0.35), size: 34)
                b.addAction(UIAction { [weak self] _ in self?.tapCell(idx) }, for: .touchUpInside)
                cells.append(b)
                rowBtns.append(b)
            }
            stack.addArrangedSubview(equalRow(rowBtns))
        }
        addRetryHomeRow { [weak self] in self?.resetGame() }
        resetGame()
    }
    private var vsCPU: Bool { modeSeg.selectedSegmentIndex == 0 }
    private func resetGame() {
        board = [Int](repeating: 0, count: 9)
        turn = 1
        over = false
        refresh()
        setStatus(vsCPU ? "あなたの番（✕）" : "プレイヤー1（✕）の番")
    }
    private func refresh() {
        for i in 0..<9 {
            cells[i].setTitle(board[i] == 1 ? "✕" : (board[i] == 2 ? "○" : "　"), for: .normal)
        }
    }
    private func winner() -> Int {
        let lines = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]]
        for l in lines where board[l[0]] != 0 && board[l[0]] == board[l[1]] && board[l[1]] == board[l[2]] { return board[l[0]] }
        return 0
    }
    private func tapCell(_ i: Int) {
        if over || board[i] != 0 { return }
        if vsCPU && turn == 2 { return }
        SoundManager.shared.click()
        board[i] = turn
        refresh()
        if checkEnd() { return }
        turn = 3 - turn
        if vsCPU && turn == 2 {
            setStatus("CPUが考え中…")
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { [weak self] in self?.cpuMove() }
        } else {
            setStatus("プレイヤー\(turn)（\(turn == 1 ? "✕" : "○")）の番")
        }
    }
    private func cpuMove() {
        if over { return }
        let idx = bestMove(for: 2, level: diffSeg.selectedSegmentIndex)
        if idx >= 0 {
            board[idx] = 2
            SoundManager.shared.playCard()
            refresh()
        }
        if checkEnd() { return }
        turn = 1
        setStatus("あなたの番（✕）")
    }
    private func checkEnd() -> Bool {
        let w = winner()
        if w != 0 {
            over = true
            if vsCPU {
                finishGame(won: w == 1, playerCount: 1, titleText: w == 1 ? "🎉 あなたの勝ち！" : "🤖 CPUの勝ち",
                           message: w == 1 ? "3つ並べた！" : "CPUに3つ並べられた…") { [weak self] in self?.resetGame() }
            } else {
                finishGame(won: w == 1, playerCount: 2, titleText: "🎉 プレイヤー\(w) の勝ち！",
                           message: "3つ並べた！") { [weak self] in self?.resetGame() }
            }
            return true
        }
        if !board.contains(0) {
            over = true
            finishGame(won: false, playerCount: vsCPU ? 1 : 2, titleText: "🤝 引き分け",
                       message: "全部埋まった！") { [weak self] in self?.resetGame() }
            return true
        }
        return false
    }
    private func bestMove(for p: Int, level: Int) -> Int {
        let empty = (0..<9).filter { board[$0] == 0 }
        if empty.isEmpty { return -1 }
        if level == 0 { return empty.randomElement() ?? -1 }
        // 勝てる手
        for i in empty { board[i] = p; let win = winner() == p; board[i] = 0; if win { return i } }
        // 負けを防ぐ手
        let opp = 3 - p
        for i in empty { board[i] = opp; let win = winner() == opp; board[i] = 0; if win { return i } }
        if level == 1 {
            if board[4] == 0 { return 4 }
            return empty.randomElement() ?? -1
        }
        // つよい：ミニマックス
        var bestScore = -100
        var bestIdx = empty[0]
        for i in empty {
            board[i] = p
            let s = minimax(isMax: false, cpu: p)
            board[i] = 0
            if s > bestScore { bestScore = s; bestIdx = i }
        }
        return bestIdx
    }
    private func minimax(isMax: Bool, cpu: Int) -> Int {
        let w = winner()
        if w == cpu { return 10 }
        if w != 0 { return -10 }
        if !board.contains(0) { return 0 }
        if isMax {
            var best = -100
            for i in 0..<9 where board[i] == 0 { board[i] = cpu; best = max(best, minimax(isMax: false, cpu: cpu)); board[i] = 0 }
            return best
        } else {
            var best = 100
            let human = 3 - cpu
            for i in 0..<9 where board[i] == 0 { board[i] = human; best = min(best, minimax(isMax: true, cpu: cpu)); board[i] = 0 }
            return best
        }
    }
}

// MARK: - 8) リバーシ（合法手表示・パス処理・CPU）
final class ReversiViewController: GameBaseViewController {
    private var board: [[Int]] = []
    private var turn = 1 // 1=黒(先手) 2=白
    private var over = false
    private var cells: [[UIButton]] = []
    private let modeSeg = UISegmentedControl(items: ["🤖 CPU対戦（あなたは黒）", "👥 2人対戦"])
    private let dirs = [(-1,-1),(-1,0),(-1,1),(0,-1),(0,1),(1,-1),(1,0),(1,1)]

    override func viewDidLoad() {
        super.viewDidLoad()
        gameId = "reversi"
        title = "リバーシ"
        stack.addArrangedSubview(makeLabel("⚫️ リバーシ", size: 22, bold: true, align: .center))
        modeSeg.selectedSegmentIndex = 0
        modeSeg.addAction(UIAction { [weak self] _ in self?.resetGame() }, for: .valueChanged)
        stack.addArrangedSubview(modeSeg)
        stack.addArrangedSubview(statusLabel)
        let grid = UIStackView()
        grid.axis = .vertical
        grid.spacing = 4
        for r in 0..<8 {
            var rowBtns: [UIButton] = []
            var rowCells: [UIButton] = []
            for c in 0..<8 {
                let b = makeButton("　", bg: UIColor(red: 0.10, green: 0.50, blue: 0.25, alpha: 1), size: 17)
                let rr = r, cc = c
                b.addAction(UIAction { [weak self] _ in self?.tapCell(rr, cc) }, for: .touchUpInside)
                rowBtns.append(b)
                rowCells.append(b)
            }
            cells.append(rowCells)
            grid.addArrangedSubview(equalRow(rowBtns))
        }
        stack.addArrangedSubview(grid)
        addRetryHomeRow { [weak self] in self?.resetGame() }
        resetGame()
    }
    private var vsCPU: Bool { modeSeg.selectedSegmentIndex == 0 }
    private func resetGame() {
        board = [[Int]](repeating: [Int](repeating: 0, count: 8), count: 8)
        board[3][3] = 2; board[3][4] = 1; board[4][3] = 1; board[4][4] = 2
        turn = 1
        over = false
        refresh()
        updateTurnStatus()
    }
    private func flips(r: Int, c: Int, p: Int) -> [(Int, Int)] {
        if board[r][c] != 0 { return [] }
        var result: [(Int, Int)] = []
        for (dr, dc) in dirs {
            var line: [(Int, Int)] = []
            var rr = r + dr, cc = c + dc
            while rr >= 0 && rr < 8 && cc >= 0 && cc < 8 && board[rr][cc] == 3 - p {
                line.append((rr, cc))
                rr += dr; cc += dc
            }
            if !line.isEmpty && rr >= 0 && rr < 8 && cc >= 0 && cc < 8 && board[rr][cc] == p {
                result += line
            }
        }
        return result
    }
    private func legalMoves(p: Int) -> [(Int, Int)] {
        var ms: [(Int, Int)] = []
        for r in 0..<8 { for c in 0..<8 { if !flips(r: r, c: c, p: p).isEmpty { ms.append((r, c)) } } }
        return ms
    }
    private func refresh() {
        let legal = over ? [] : legalMoves(p: turn)
        for r in 0..<8 {
            for c in 0..<8 {
                let b = cells[r][c]
                if board[r][c] == 1 { b.setTitle("⚫", for: .normal) }
                else if board[r][c] == 2 { b.setTitle("⚪", for: .normal) }
                else if legal.contains(where: { $0.0 == r && $0.1 == c }) { b.setTitle("・", for: .normal) }
                else { b.setTitle("　", for: .normal) }
            }
        }
    }
    private func counts() -> (Int, Int) {
        var b = 0, w = 0
        for row in board { for v in row { if v == 1 { b += 1 } else if v == 2 { w += 1 } } }
        return (b, w)
    }
    private func updateTurnStatus() {
        let (b, w) = counts()
        setStatus("\(turn == 1 ? "⚫ 黒" : "⚪ 白") の番　｜　黒 \(b) ： 白 \(w)")
    }
    private func tapCell(_ r: Int, _ c: Int) {
        if over { return }
        if vsCPU && turn == 2 { return }
        let f = flips(r: r, c: c, p: turn)
        if f.isEmpty { return }
        place(r: r, c: c, p: turn, f: f)
        advance()
    }
    private func place(r: Int, c: Int, p: Int, f: [(Int, Int)]) {
        SoundManager.shared.playCard()
        board[r][c] = p
        for (rr, cc) in f { board[rr][cc] = p }
        refresh()
    }
    private func advance() {
        let next = 3 - turn
        if !legalMoves(p: next).isEmpty {
            turn = next
            refresh()
            updateTurnStatus()
            if vsCPU && turn == 2 {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) { [weak self] in self?.cpuMove() }
            }
        } else if !legalMoves(p: turn).isEmpty {
            // 相手はパス
            let a = UIAlertController(title: "パス", message: "\(next == 1 ? "黒" : "白") は置ける場所がないのでパスします", preferredStyle: .alert)
            a.addAction(UIAlertAction(title: "OK", style: .default))
            present(a, animated: true)
            refresh()
            updateTurnStatus()
            if vsCPU && turn == 2 {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) { [weak self] in self?.cpuMove() }
            }
        } else {
            endGame()
        }
    }
    private func cpuMove() {
        if over || turn != 2 { return }
        let ms = legalMoves(p: 2)
        if ms.isEmpty { advance(); return }
        var best = ms[0]
        var bestScore = -10000
        for (r, c) in ms {
            var s = flips(r: r, c: c, p: 2).count * 10
            if (r == 0 || r == 7) && (c == 0 || c == 7) { s += 100 }
            else if r == 0 || r == 7 || c == 0 || c == 7 { s += 15 }
            if s > bestScore { bestScore = s; best = (r, c) }
        }
        place(r: best.0, c: best.1, p: 2, f: flips(r: best.0, c: best.1, p: 2))
        advance()
    }
    private func endGame() {
        over = true
        refresh()
        let (b, w) = counts()
        if b == w {
            finishGame(won: false, playerCount: vsCPU ? 1 : 2, titleText: "🤝 引き分け", message: "黒 \(b) ： 白 \(w)") { [weak self] in self?.resetGame() }
        } else {
            let blackWin = b > w
            let won = vsCPU ? blackWin : blackWin
            finishGame(won: won, playerCount: vsCPU ? 1 : 2,
                       titleText: blackWin ? "⚫ 黒の勝ち！" : "⚪ 白の勝ち！",
                       message: "黒 \(b) ： 白 \(w)") { [weak self] in self?.resetGame() }
        }
    }
}

// MARK: - 9) 五目並べ（13×13・CPU簡易評価／2人）
final class GomokuViewController: GameBaseViewController {
    private let size = 13
    private var board: [[Int]] = []
    private var turn = 1
    private var over = false
    private var cells: [[UIButton]] = []
    private let modeSeg = UISegmentedControl(items: ["🤖 CPU対戦（あなたは先手）", "👥 2人対戦"])
    private let dirs = [(1, 0), (0, 1), (1, 1), (1, -1)]

    override func viewDidLoad() {
        super.viewDidLoad()
        gameId = "gomoku"
        title = "五目並べ"
        stack.addArrangedSubview(makeLabel("🔵 五目並べ（13×13）", size: 22, bold: true, align: .center))
        modeSeg.selectedSegmentIndex = 0
        modeSeg.addAction(UIAction { [weak self] _ in self?.resetGame() }, for: .valueChanged)
        stack.addArrangedSubview(modeSeg)
        stack.addArrangedSubview(statusLabel)
        let grid = UIStackView()
        grid.axis = .vertical
        grid.spacing = 2
        for r in 0..<size {
            var rowBtns: [UIButton] = []
            var rowCells: [UIButton] = []
            for c in 0..<size {
                let b = makeButton("＋", bg: UIColor(red: 0.85, green: 0.70, blue: 0.45, alpha: 1), size: 11)
                b.setTitleColor(UIColor.black.withAlphaComponent(0.5), for: .normal)
                let rr = r, cc = c
                b.addAction(UIAction { [weak self] _ in self?.tapCell(rr, cc) }, for: .touchUpInside)
                rowBtns.append(b)
                rowCells.append(b)
            }
            cells.append(rowCells)
            grid.addArrangedSubview(equalRow(rowBtns))
        }
        stack.addArrangedSubview(grid)
        stack.addArrangedSubview(makeLabel("🔴＝プレイヤー1／先手、🔵＝プレイヤー2／CPU", size: 12, align: .center))
        addRetryHomeRow { [weak self] in self?.resetGame() }
        resetGame()
    }
    private var vsCPU: Bool { modeSeg.selectedSegmentIndex == 0 }
    private func resetGame() {
        board = [[Int]](repeating: [Int](repeating: 0, count: size), count: size)
        turn = 1
        over = false
        for r in 0..<size { for c in 0..<size {
            cells[r][c].setTitle("＋", for: .normal)
            cells[r][c].setTitleColor(UIColor.black.withAlphaComponent(0.5), for: .normal)
        } }
        setStatus("プレイヤー1（🔴）の番")
    }
    private func inB(_ r: Int, _ c: Int) -> Bool { r >= 0 && r < size && c >= 0 && c < size }
    private func countLine(r: Int, c: Int, dr: Int, dc: Int, p: Int) -> (Int, Int) {
        var cnt = 1
        var open = 0
        var rr = r + dr, cc = c + dc
        while inB(rr, cc) && board[rr][cc] == p { cnt += 1; rr += dr; cc += dc }
        if inB(rr, cc) && board[rr][cc] == 0 { open += 1 }
        rr = r - dr; cc = c - dc
        while inB(rr, cc) && board[rr][cc] == p { cnt += 1; rr -= dr; cc -= dc }
        if inB(rr, cc) && board[rr][cc] == 0 { open += 1 }
        return (cnt, open)
    }
    private func isWin(r: Int, c: Int, p: Int) -> Bool {
        for (dr, dc) in dirs { if countLine(r: r, c: c, dr: dr, dc: dc, p: p).0 >= 5 { return true } }
        return false
    }
    private func place(_ r: Int, _ c: Int, _ p: Int) {
        board[r][c] = p
        cells[r][c].setTitle("●", for: .normal)
        cells[r][c].setTitleColor(p == 1 ? UIColor(red: 0.85, green: 0.15, blue: 0.15, alpha: 1) : UIColor(red: 0.10, green: 0.30, blue: 0.85, alpha: 1), for: .normal)
        SoundManager.shared.playCard()
    }
    private func tapCell(_ r: Int, _ c: Int) {
        if over || board[r][c] != 0 { return }
        if vsCPU && turn == 2 { return }
        place(r, c, turn)
        if isWin(r: r, c: c, p: turn) { endWin(p: turn); return }
        if board.flatMap({ $0 }).allSatisfy({ $0 != 0 }) {
            over = true
            finishGame(won: false, playerCount: vsCPU ? 1 : 2, titleText: "🤝 引き分け", message: "盤が全部埋まった！") { [weak self] in self?.resetGame() }
            return
        }
        turn = 3 - turn
        if vsCPU && turn == 2 {
            setStatus("CPUが考え中…")
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) { [weak self] in self?.cpuMove() }
        } else {
            setStatus("プレイヤー\(turn)（\(turn == 1 ? "🔴" : "🔵")）の番")
        }
    }
    private func lineScore(_ cnt: Int, _ open: Int) -> Int {
        if cnt >= 5 { return 100000 }
        if open == 0 { return 0 }
        switch cnt {
        case 4: return open == 2 ? 10000 : 1000
        case 3: return open == 2 ? 500 : 60
        case 2: return open == 2 ? 40 : 8
        default: return 2
        }
    }
    private func cellScore(r: Int, c: Int, p: Int) -> Int {
        var s = 0
        for (dr, dc) in dirs {
            let (cnt, open) = countLine(r: r, c: c, dr: dr, dc: dc, p: p)
            s += lineScore(cnt, open)
        }
        return s
    }
    private func cpuMove() {
        if over || turn != 2 { return }
        var best = (-1, -1)
        var bestScore = -1
        for r in 0..<size {
            for c in 0..<size where board[r][c] == 0 {
                // 近くに石がある場所だけ評価（高速化）
                var near = false
                for dr in -2...2 { for dc in -2...2 { if inB(r + dr, c + dc) && board[r + dr][c + dc] != 0 { near = true } } }
                if !near { continue }
                let attack = cellScore(r: r, c: c, p: 2)
                let defense = cellScore(r: r, c: c, p: 1)
                let s = attack + Int(Double(defense) * 0.9)
                if s > bestScore { bestScore = s; best = (r, c) }
            }
        }
        if best.0 < 0 { best = (size / 2, size / 2) }
        place(best.0, best.1, 2)
        if isWin(r: best.0, c: best.1, p: 2) { endWin(p: 2); return }
        turn = 1
        setStatus("あなたの番（🔴）")
    }
    private func endWin(p: Int) {
        over = true
        if vsCPU {
            finishGame(won: p == 1, playerCount: 1, titleText: p == 1 ? "🎉 あなたの勝ち！" : "🤖 CPUの勝ち",
                       message: "5つ並んだ！") { [weak self] in self?.resetGame() }
        } else {
            finishGame(won: p == 1, playerCount: 2, titleText: "🎉 プレイヤー\(p) の勝ち！",
                       message: "5つ並んだ！") { [weak self] in self?.resetGame() }
        }
    }
}
