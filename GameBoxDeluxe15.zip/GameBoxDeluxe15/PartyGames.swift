import UIKit

// MARK: - 1) サイコロレース（すごろく風・30マス）
final class DiceRaceViewController: GameBaseViewController {
    private let n: Int
    private var positions: [Int] = []
    private var current = 0
    private var started = false
    private let boardLabel = UILabel()
    private let diceLabel = UILabel()
    private var rollBtn: UIButton!
    private let goal = 30
    private let events: [Int: Int] = [5: 3, 9: -2, 13: 4, 18: -3, 23: 2, 27: 3]

    init(playerCount: Int) { n = playerCount; super.init(nibName: nil, bundle: nil) }
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    override func viewDidLoad() {
        super.viewDidLoad()
        gameId = "diceRace"
        title = "サイコロレース"
        stack.addArrangedSubview(makeLabel("🎲 サイコロレース（ゴールは \(goal) マス）", size: 22, bold: true, align: .center))
        stack.addArrangedSubview(makeLabel("イベントマス：5→+3、9→-2、13→+4、18→-3、23→+2、27→+3", size: 12, align: .center))
        stack.addArrangedSubview(statusLabel)
        diceLabel.font = UIFont.boldSystemFont(ofSize: 54)
        diceLabel.textAlignment = .center
        diceLabel.text = "🎲"
        stack.addArrangedSubview(diceLabel)
        boardLabel.font = UIFont.systemFont(ofSize: 15)
        boardLabel.textColor = .white
        boardLabel.numberOfLines = 0
        stack.addArrangedSubview(boardLabel)
        rollBtn = makeButton("🎲 サイコロを振る！", bg: UIColor(red: 0.85, green: 0.30, blue: 0.10, alpha: 1), size: 20)
        rollBtn.addAction(UIAction { [weak self] _ in self?.roll() }, for: .touchUpInside)
        stack.addArrangedSubview(rollBtn)
        addRetryHomeRow { [weak self] in self?.resetGame() }
        resetGame()
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if !started { started = true; beginTurn() }
    }
    private func resetGame() {
        positions = [Int](repeating: 0, count: n)
        current = 0
        diceLabel.text = "🎲"
        updateBoard()
        beginTurn()
    }
    private func beginTurn() {
        rollBtn.isEnabled = false
        setStatus("\(playerMarks[current]) プレイヤー\(current + 1) の番です")
        updateBoard()
        showPassCover(playerName: "\(playerMarks[current]) プレイヤー\(current + 1)") { [weak self] in
            self?.rollBtn.isEnabled = true
        }
    }
    private func updateBoard() {
        var lines: [String] = []
        for i in 0..<n {
            let bar = String(repeating: "・", count: positions[i]) + "🚩"
            lines.append("\(playerMarks[i]) P\(i + 1)：\(positions[i])/\(goal) \(bar)")
        }
        boardLabel.text = lines.joined(separator: "\n")
    }
    private func roll() {
        SoundManager.shared.playCard()
        SoundManager.shared.haptic()
        let v = Int.random(in: 1...6)
        let faces = ["⚀", "⚁", "⚂", "⚃", "⚄", "⚅"]
        diceLabel.text = faces[v - 1]
        positions[current] += v
        var msg = "\(v) が出た！"
        if positions[current] < goal, let e = events[positions[current]] {
            positions[current] = max(0, positions[current] + e)
            msg += e > 0 ? " イベントマス！ \(e) マス進む！" : " イベントマス… \(-e) マス戻る"
        }
        if positions[current] >= goal {
            positions[current] = goal
            updateBoard()
            setStatus("🏁 プレイヤー\(current + 1) がゴール！")
            let winner = current
            finishGame(won: winner == 0, playerCount: n, titleText: "🏁 ゴール！",
                       message: "\(playerMarks[winner]) プレイヤー\(winner + 1) の勝ち！") { [weak self] in self?.resetGame() }
            return
        }
        setStatus("プレイヤー\(current + 1)：\(msg)")
        updateBoard()
        rollBtn.isEnabled = false
        current = (current + 1) % n
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.9) { [weak self] in self?.beginTurn() }
    }
}

// MARK: - 2) じゃんけん大会（勝ち抜き・先に3点、CPU補充可）
final class JankenViewController: GameBaseViewController {
    private let humans: Int
    private var total: Int
    private var scores: [Int] = []
    private var choices: [Int] = []
    private var collecting = 0
    private var started = false
    private let cpuSwitch = UISwitch()
    private let scoreLabel = UILabel()
    private var handBtns: [UIButton] = []

    init(playerCount: Int) { humans = playerCount; total = playerCount; super.init(nibName: nil, bundle: nil) }
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    override func viewDidLoad() {
        super.viewDidLoad()
        gameId = "janken"
        title = "じゃんけん大会"
        stack.addArrangedSubview(makeLabel("✊ じゃんけん大会（先に3点で優勝）", size: 22, bold: true, align: .center))
        let row = UIStackView()
        row.axis = .horizontal
        row.spacing = 8
        row.addArrangedSubview(makeLabel("CPU補充（合計7人にする）", size: 14))
        cpuSwitch.isOn = false
        cpuSwitch.addAction(UIAction { [weak self] _ in self?.resetGame() }, for: .valueChanged)
        row.addArrangedSubview(cpuSwitch)
        stack.addArrangedSubview(row)
        stack.addArrangedSubview(statusLabel)
        scoreLabel.font = UIFont.systemFont(ofSize: 15)
        scoreLabel.textColor = .white
        scoreLabel.numberOfLines = 0
        stack.addArrangedSubview(scoreLabel)
        let names = ["✊ グー", "✌️ チョキ", "🖐 パー"]
        var bs: [UIButton] = []
        for i in 0..<3 {
            let b = makeButton(names[i], bg: playerColor(i), size: 20)
            let idx = i
            b.addAction(UIAction { [weak self] _ in self?.choose(idx) }, for: .touchUpInside)
            bs.append(b)
            handBtns.append(b)
        }
        stack.addArrangedSubview(equalRow(bs))
        addRetryHomeRow { [weak self] in self?.resetGame() }
        resetGame()
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if !started { started = true; beginRound() }
    }
    private func resetGame() {
        total = cpuSwitch.isOn ? 7 : humans
        scores = [Int](repeating: 0, count: total)
        updateScores()
        beginRound()
    }
    private func participantName(_ i: Int) -> String {
        i < humans ? "\(playerMarks[i]) プレイヤー\(i + 1)" : "🤖 CPU\(i - humans + 1)"
    }
    private func updateScores() {
        scoreLabel.text = (0..<total).map { "\(participantName($0))：\(scores[$0])点" }.joined(separator: "\n")
    }
    private func beginRound() {
        choices = [Int](repeating: -1, count: total)
        collecting = 0
        collectNext()
    }
    private func collectNext() {
        if collecting >= humans {
            for i in humans..<total { choices[i] = Int.random(in: 0...2) }
            judge()
            return
        }
        for b in handBtns { b.isEnabled = false }
        setStatus("\(participantName(collecting))、手を選んでね")
        showPassCover(playerName: participantName(collecting)) { [weak self] in
            guard let self = self else { return }
            for b in self.handBtns { b.isEnabled = true }
        }
    }
    private func choose(_ hand: Int) {
        SoundManager.shared.click()
        SoundManager.shared.haptic()
        choices[collecting] = hand
        collecting += 1
        collectNext()
    }
    private func judge() {
        let handNames = ["✊", "✌️", "🖐"]
        let present = Array(Set(choices.filter { $0 >= 0 }))
        var result = "みんなの手：" + (0..<total).map { "\(participantName($0)) \(handNames[choices[$0]])" }.joined(separator: "、")
        if present.count == 2 {
            let a = present[0], b = present[1]
            let winnerHand = ((a == 0 && b == 2) || (a == 2 && b == 1) || (a == 1 && b == 0)) ? a : b
            var winners: [Int] = []
            for i in 0..<total where choices[i] == winnerHand {
                scores[i] += 1
                winners.append(i)
            }
            result += "\n勝った手 \(handNames[winnerHand]) の \(winners.map { participantName($0) }.joined(separator: "、")) に1点！"
        } else {
            result += "\nあいこ！点数なし"
        }
        updateScores()
        setStatus(result)
        let champs = (0..<total).filter { scores[$0] >= 3 }
        if !champs.isEmpty {
            let names = champs.map { participantName($0) }.joined(separator: "、")
            finishGame(won: champs.contains(0), playerCount: total, titleText: "🏆 優勝！",
                       message: "\(names) が3点で優勝！") { [weak self] in self?.resetGame() }
            return
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.6) { [weak self] in self?.beginRound() }
    }
}

// MARK: - 3) 神経衰弱
final class MemoryGameViewController: GameBaseViewController {
    private let n: Int
    private var pairCount = 8
    private var deck: [String] = []
    private var matched: [Bool] = []
    private var firstPick = -1
    private var lock = false
    private var scores: [Int] = []
    private var current = 0
    private var started = false
    private var buttons: [UIButton] = []
    private let gridStack = UIStackView()
    private let symbols = ["🍎", "🍌", "🍇", "🍓", "🍑", "🥝", "🍍", "🍒", "🍉", "🍋", "🍊", "🥥"]

    init(playerCount: Int) { n = playerCount; super.init(nibName: nil, bundle: nil) }
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    override func viewDidLoad() {
        super.viewDidLoad()
        gameId = "memory"
        title = "神経衰弱"
        stack.addArrangedSubview(makeLabel("🃏 神経衰弱", size: 22, bold: true, align: .center))
        let seg = UISegmentedControl(items: ["6ペア", "8ペア", "10ペア"])
        seg.selectedSegmentIndex = 1
        seg.addAction(UIAction { [weak self] _ in
            guard let self = self else { return }
            self.pairCount = [6, 8, 10][seg.selectedSegmentIndex]
            self.resetGame()
        }, for: .valueChanged)
        stack.addArrangedSubview(seg)
        stack.addArrangedSubview(statusLabel)
        gridStack.axis = .vertical
        gridStack.spacing = 8
        stack.addArrangedSubview(gridStack)
        addRetryHomeRow { [weak self] in self?.resetGame() }
        resetGame()
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if !started { started = true; beginTurn() }
    }
    private func resetGame() {
        let syms = Array(symbols.shuffled().prefix(pairCount))
        deck = (syms + syms).shuffled()
        matched = [Bool](repeating: false, count: deck.count)
        firstPick = -1
        lock = false
        scores = [Int](repeating: 0, count: n)
        current = 0
        buildGrid()
        updateStatus()
        if started { beginTurn() }
    }
    private func buildGrid() {
        gridStack.arrangedSubviews.forEach { $0.removeFromSuperview() }
        buttons = []
        var idx = 0
        while idx < deck.count {
            var rowBtns: [UIView] = []
            for _ in 0..<4 {
                if idx >= deck.count { break }
                let b = makeButton("❓", bg: UIColor(red: 0.20, green: 0.35, blue: 0.70, alpha: 1), size: 22)
                let myIdx = idx
                b.addAction(UIAction { [weak self] _ in self?.flip(myIdx) }, for: .touchUpInside)
                buttons.append(b)
                rowBtns.append(b)
                idx += 1
            }
            while rowBtns.count < 4 { rowBtns.append(UIView()) }
            gridStack.addArrangedSubview(equalRow(rowBtns))
        }
    }
    private func scoreText() -> String {
        (0..<n).map { "\(playerMarks[$0]) P\($0 + 1)：\(scores[$0])ペア" }.joined(separator: "　")
    }
    private func updateStatus() { setStatus("\(playerMarks[current]) プレイヤー\(current + 1) の番　｜　\(scoreText())") }
    private func beginTurn() {
        updateStatus()
        showPassCover(playerName: "\(playerMarks[current]) プレイヤー\(current + 1)") { }
    }
    private func flip(_ i: Int) {
        if lock || matched[i] || i == firstPick { return }
        SoundManager.shared.flip()
        buttons[i].setTitle(deck[i], for: .normal)
        buttons[i].backgroundColor = UIColor(red: 0.95, green: 0.80, blue: 0.25, alpha: 1)
        if firstPick < 0 { firstPick = i; return }
        lock = true
        let a = firstPick
        firstPick = -1
        if deck[a] == deck[i] {
            matched[a] = true; matched[i] = true
            scores[current] += 1
            SoundManager.shared.buy()
            setStatus("🎉 ペア成立！ プレイヤー\(current + 1) は続けてめくれる　｜　\(scoreText())")
            lock = false
            if matched.allSatisfy({ $0 }) { endGame() }
        } else {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) { [weak self] in
                guard let self = self else { return }
                for j in [a, i] {
                    self.buttons[j].setTitle("❓", for: .normal)
                    self.buttons[j].backgroundColor = UIColor(red: 0.20, green: 0.35, blue: 0.70, alpha: 1)
                }
                self.lock = false
                self.current = (self.current + 1) % self.n
                self.beginTurn()
            }
        }
    }
    private func endGame() {
        let maxScore = scores.max() ?? 0
        let winners = (0..<n).filter { scores[$0] == maxScore }
        let names = winners.map { "プレイヤー\($0 + 1)" }.joined(separator: "、")
        finishGame(won: winners.contains(0), playerCount: n, titleText: "🏆 結果",
                   message: "\(names) が \(maxScore) ペアで勝ち！\n\(scoreText())") { [weak self] in self?.resetGame() }
    }
}

// MARK: - 4) 数字当て大会（1〜100）
final class NumGuessViewController: GameBaseViewController {
    private let n: Int
    private var secret = 50
    private var current = 0
    private var low = 1
    private var high = 100
    private var attempts: [Int] = []
    private var started = false
    private let field = UITextField()
    private let rangeLabel = UILabel()

    init(playerCount: Int) { n = playerCount; super.init(nibName: nil, bundle: nil) }
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    override func viewDidLoad() {
        super.viewDidLoad()
        gameId = "numGuess"
        title = "数字当て大会"
        stack.addArrangedSubview(makeLabel("🔢 数字当て大会（1〜100）", size: 22, bold: true, align: .center))
        stack.addArrangedSubview(statusLabel)
        rangeLabel.font = UIFont.boldSystemFont(ofSize: 20)
        rangeLabel.textColor = .yellow
        rangeLabel.textAlignment = .center
        stack.addArrangedSubview(rangeLabel)
        field.borderStyle = .roundedRect
        field.keyboardType = .numberPad
        field.placeholder = "予想する数字を入力"
        field.font = UIFont.systemFont(ofSize: 20)
        field.textAlignment = .center
        stack.addArrangedSubview(field)
        let guessBtn = makeButton("🎯 当てる！", bg: UIColor(red: 0.85, green: 0.30, blue: 0.10, alpha: 1), size: 20)
        guessBtn.addAction(UIAction { [weak self] _ in self?.guess() }, for: .touchUpInside)
        stack.addArrangedSubview(guessBtn)
        addRetryHomeRow { [weak self] in self?.resetGame() }
        resetGame()
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if !started { started = true; beginTurn() }
    }
    private func resetGame() {
        secret = Int.random(in: 1...100)
        current = 0
        low = 1; high = 100
        attempts = [Int](repeating: 0, count: n)
        field.text = ""
        rangeLabel.text = "範囲：\(low) 〜 \(high)"
        if started { beginTurn() } else { updateStatus("数字を予想してね") }
    }
    private func updateStatus(_ extra: String) {
        setStatus("\(playerMarks[current]) プレイヤー\(current + 1) の番　\(extra)")
    }
    private func beginTurn() {
        updateStatus("")
        showPassCover(playerName: "\(playerMarks[current]) プレイヤー\(current + 1)") { [weak self] in self?.field.becomeFirstResponder() }
    }
    private func guess() {
        guard let t = field.text, let v = Int(t), v >= 1, v <= 100 else {
            setStatus("1〜100の数字を入れてね")
            return
        }
        field.text = ""
        attempts[current] += 1
        SoundManager.shared.click()
        if v == secret {
            let winner = current
            finishGame(won: winner == 0, playerCount: n, titleText: "🎯 大当たり！",
                       message: "正解は \(secret)！ プレイヤー\(winner + 1) が \(attempts[winner]) 回目で当てた！") { [weak self] in self?.resetGame() }
            return
        }
        if v < secret { low = max(low, v + 1); updateStatus("ヒント：もっと大きい！") }
        else { high = min(high, v - 1); updateStatus("ヒント：もっと小さい！") }
        rangeLabel.text = "範囲：\(low) 〜 \(high)"
        current = (current + 1) % n
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.7) { [weak self] in self?.beginTurn() }
    }
}

// MARK: - 5) 爆弾パス（脱落式）
final class BombPassViewController: GameBaseViewController {
    private let n: Int
    private var alive: [Bool] = []
    private var holder = 0
    private var timer: Timer?
    private var fuse: Double = 12
    private var elapsed: Double = 0
    private var running = false
    private let bombLabel = UILabel()
    private var passBtn: UIButton!
    private var startBtn: UIButton!

    init(playerCount: Int) { n = playerCount; super.init(nibName: nil, bundle: nil) }
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    override func viewDidLoad() {
        super.viewDidLoad()
        gameId = "bombPass"
        title = "爆弾パス"
        stack.addArrangedSubview(makeLabel("💣 爆弾パス（最後の1人が勝ち）", size: 22, bold: true, align: .center))
        stack.addArrangedSubview(statusLabel)
        bombLabel.font = UIFont.boldSystemFont(ofSize: 64)
        bombLabel.textAlignment = .center
        bombLabel.text = "💣"
        stack.addArrangedSubview(bombLabel)
        startBtn = makeButton("▶ 爆弾スタート！", bg: UIColor(red: 0.10, green: 0.55, blue: 0.30, alpha: 1), size: 20)
        startBtn.addAction(UIAction { [weak self] _ in self?.startRound() }, for: .touchUpInside)
        stack.addArrangedSubview(startBtn)
        passBtn = makeButton("💨 パス！（次の人へ）", bg: UIColor(red: 0.85, green: 0.30, blue: 0.10, alpha: 1), size: 22)
        passBtn.addAction(UIAction { [weak self] _ in self?.passBomb() }, for: .touchUpInside)
        passBtn.isEnabled = false
        stack.addArrangedSubview(passBtn)
        addRetryHomeRow { [weak self] in self?.resetGame() }
        resetGame()
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        timer?.invalidate(); timer = nil
    }
    private func aliveNames() -> String {
        (0..<n).map { alive[$0] ? "\(playerMarks[$0]) P\($0 + 1)" : "💀 P\($0 + 1)" }.joined(separator: "　")
    }
    private func resetGame() {
        timer?.invalidate(); timer = nil
        running = false
        alive = [Bool](repeating: true, count: n)
        holder = 0
        bombLabel.text = "💣"
        passBtn.isEnabled = false
        startBtn.isEnabled = true
        setStatus("残っている人：\(aliveNames())")
    }
    private func startRound() {
        if alive.filter({ $0 }).count <= 1 { return }
        fuse = Double.random(in: 8...20)
        elapsed = 0
        running = true
        startBtn.isEnabled = false
        passBtn.isEnabled = true
        timer?.invalidate()
        timer = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { [weak self] _ in self?.tick() }
        announceHolder()
    }
    private func announceHolder() {
        setStatus("💣 爆弾は \(playerMarks[holder]) プレイヤー\(holder + 1) が持っている！早くパス！\n残り：\(aliveNames())")
        showPassCover(playerName: "\(playerMarks[holder]) プレイヤー\(holder + 1)") { }
    }
    private func passBomb() {
        guard running else { return }
        SoundManager.shared.click()
        SoundManager.shared.haptic()
        hidePassCover()
        repeat { holder = (holder + 1) % n } while !alive[holder]
        announceHolder()
    }
    private func tick() {
        guard running else { return }
        elapsed += 0.1
        let remain = fuse - elapsed
        if remain < 3 || elapsed.truncatingRemainder(dividingBy: 1.0) < 0.1 { SoundManager.shared.click() }
        bombLabel.text = remain < 3 ? "🧨" : "💣"
        if elapsed >= fuse { explode() }
    }
    private func explode() {
        running = false
        timer?.invalidate(); timer = nil
        passBtn.isEnabled = false
        bombLabel.text = "💥"
        SoundManager.shared.boom()
        alive[holder] = false
        let left = (0..<n).filter { alive[$0] }
        if left.count == 1 {
            let w = left[0]
            setStatus("🏆 プレイヤー\(w + 1) が最後まで残った！")
            finishGame(won: w == 0, playerCount: n, titleText: "🏆 勝ち残り！",
                       message: "\(playerMarks[w]) プレイヤー\(w + 1) の勝ち！") { [weak self] in self?.resetGame() }
        } else {
            setStatus("💥 プレイヤー\(holder + 1) が脱落… 残り \(left.count) 人")
            holder = left[0]
            startBtn.isEnabled = true
        }
    }
}

// MARK: - 6) クイズ大会（オリジナル24問・12問勝負）
struct QuizQ { let q: String; let choices: [String]; let answer: Int }
let quizBank: [QuizQ] = [
    QuizQ(q: "日本で一番高い山は？", choices: ["富士山", "北岳", "槍ヶ岳", "白馬岳"], answer: 0),
    QuizQ(q: "水の化学式は？", choices: ["CO2", "H2O", "O2", "NaCl"], answer: 1),
    QuizQ(q: "1週間は何日？", choices: ["5日", "6日", "7日", "8日"], answer: 2),
    QuizQ(q: "パンダの主食は？", choices: ["笹", "肉", "魚", "果物だけ"], answer: 0),
    QuizQ(q: "地球から一番近い星は？", choices: ["月", "火星", "太陽", "金星"], answer: 2),
    QuizQ(q: "サイコロの目の合計（向かい合う面）は？", choices: ["6", "7", "8", "9"], answer: 1),
    QuizQ(q: "日本の首都は？", choices: ["大阪", "京都", "東京", "名古屋"], answer: 2),
    QuizQ(q: "雪がとけると何になる？", choices: ["氷", "水", "雲", "霧"], answer: 1),
    QuizQ(q: "ひまわりの花が向く方向は？", choices: ["北", "太陽", "南", "風上"], answer: 1),
    QuizQ(q: "1年はうるう年以外で何日？", choices: ["360日", "364日", "365日", "366日"], answer: 2),
    QuizQ(q: "タコの足は何本？", choices: ["6本", "8本", "10本", "12本"], answer: 1),
    QuizQ(q: "虹の色は何色？", choices: ["5色", "6色", "7色", "8色"], answer: 2),
    QuizQ(q: "人間の心臓はどこにある？", choices: ["お腹", "胸", "背中", "頭"], answer: 1),
    QuizQ(q: "ピザの発祥の国は？", choices: ["フランス", "アメリカ", "イタリア", "スペイン"], answer: 2),
    QuizQ(q: "一番大きい惑星は？", choices: ["土星", "木星", "海王星", "地球"], answer: 1),
    QuizQ(q: "将棋の駒で一番強い（王の横）のは？", choices: ["歩", "金", "角", "飛車"], answer: 1),
    QuizQ(q: "カタツムリの別名は？", choices: ["でんでんむし", "かたつむり丸", "まいまい虫", "ぬめり虫"], answer: 0),
    QuizQ(q: "100円玉の絵柄の植物は？", choices: ["梅", "桜", "菊", "松"], answer: 1),
    QuizQ(q: "かき氷にかける甘い液体を何という？", choices: ["ソース", "シロップ", "タレ", "ジャム"], answer: 1),
    QuizQ(q: "サッカーの試合、1チーム何人？", choices: ["9人", "10人", "11人", "12人"], answer: 2),
    QuizQ(q: "牛乳から作る、ピザにのせる食べ物は？", choices: ["バター", "チーズ", "ヨーグルト", "生クリーム"], answer: 1),
    QuizQ(q: "夜空で一番明るい星（恒星）は？", choices: ["北極星", "シリウス", "織姫星", "太陽"], answer: 1),
    QuizQ(q: "亀の甲羅は体のどの部分が変化したもの？", choices: ["皮膚と肋骨", "爪", "歯", "角"], answer: 0),
    QuizQ(q: "「三寒四温」は何の季節の言葉？", choices: ["春先", "真夏", "秋", "真冬"], answer: 0),
]

final class QuizViewController: GameBaseViewController {
    private let n: Int
    private var questions: [QuizQ] = []
    private var qi = 0
    private var scores: [Int] = []
    private var started = false
    private var choiceBtns: [UIButton] = []
    private let questionLabel = UILabel()

    init(playerCount: Int) { n = playerCount; super.init(nibName: nil, bundle: nil) }
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    override func viewDidLoad() {
        super.viewDidLoad()
        gameId = "quiz"
        title = "クイズ大会"
        stack.addArrangedSubview(makeLabel("❓ クイズ大会（12問・正解10点）", size: 22, bold: true, align: .center))
        stack.addArrangedSubview(statusLabel)
        questionLabel.font = UIFont.boldSystemFont(ofSize: 19)
        questionLabel.textColor = .white
        questionLabel.numberOfLines = 0
        stack.addArrangedSubview(questionLabel)
        for i in 0..<4 {
            let b = makeButton("", bg: UIColor.black.withAlphaComponent(0.35), size: 17)
            let idx = i
            b.addAction(UIAction { [weak self] _ in self?.answer(idx) }, for: .touchUpInside)
            choiceBtns.append(b)
            stack.addArrangedSubview(b)
        }
        addRetryHomeRow { [weak self] in self?.resetGame() }
        resetGame()
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if !started { started = true; beginQuestion() }
    }
    private func scoreText() -> String {
        (0..<n).map { "\(playerMarks[$0]) P\($0 + 1)：\(scores[$0])点" }.joined(separator: "　")
    }
    private func resetGame() {
        questions = Array(quizBank.shuffled().prefix(12))
        qi = 0
        scores = [Int](repeating: 0, count: n)
        if started { beginQuestion() }
    }
    private var currentPlayer: Int { qi % n }
    private func beginQuestion() {
        if qi >= questions.count { endGame(); return }
        let q = questions[qi]
        setStatus("第\(qi + 1)問　\(playerMarks[currentPlayer]) プレイヤー\(currentPlayer + 1) の番　｜　\(scoreText())")
        questionLabel.text = "Q. \(q.q)"
        for (i, b) in choiceBtns.enumerated() {
            b.setTitle(q.choices[i], for: .normal)
            b.isEnabled = false
            b.backgroundColor = UIColor.black.withAlphaComponent(0.35)
        }
        showPassCover(playerName: "\(playerMarks[currentPlayer]) プレイヤー\(currentPlayer + 1)") { [weak self] in
            guard let self = self else { return }
            for b in self.choiceBtns { b.isEnabled = true }
        }
    }
    private func answer(_ idx: Int) {
        let q = questions[qi]
        SoundManager.shared.click()
        for b in choiceBtns { b.isEnabled = false }
        if idx == q.answer {
            scores[currentPlayer] += 10
            choiceBtns[idx].backgroundColor = UIColor(red: 0.10, green: 0.60, blue: 0.30, alpha: 1)
            SoundManager.shared.buy()
            setStatus("🎉 正解！ +10点　｜　\(scoreText())")
        } else {
            choiceBtns[idx].backgroundColor = UIColor(red: 0.75, green: 0.15, blue: 0.15, alpha: 1)
            choiceBtns[q.answer].backgroundColor = UIColor(red: 0.10, green: 0.60, blue: 0.30, alpha: 1)
            SoundManager.shared.bad()
            setStatus("❌ 残念… 正解は「\(q.choices[q.answer])」　｜　\(scoreText())")
        }
        qi += 1
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.4) { [weak self] in self?.beginQuestion() }
    }
    private func endGame() {
        let maxScore = scores.max() ?? 0
        let winners = (0..<n).filter { scores[$0] == maxScore }
        let names = winners.map { "プレイヤー\($0 + 1)" }.joined(separator: "、")
        finishGame(won: winners.contains(0), playerCount: n, titleText: "🏆 クイズ結果",
                   message: "\(names) が \(maxScore) 点で勝ち！\n\(scoreText())") { [weak self] in self?.resetGame() }
    }
}
