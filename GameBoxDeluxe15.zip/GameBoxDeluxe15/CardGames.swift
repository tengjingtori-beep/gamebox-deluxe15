import UIKit

func rankText(_ r: Int) -> String {
    switch r {
    case 1: return "A"
    case 11: return "J"
    case 12: return "Q"
    case 13: return "K"
    default: return "\(r)"
    }
}
let suitEmojis = ["♠️", "♥️", "♦️", "♣️"]
func makeDeck() -> [(rank: Int, suit: Int)] {
    var d: [(rank: Int, suit: Int)] = []
    for s in 0..<4 { for r in 1...13 { d.append((r, s)) } }
    return d.shuffled()
}
func cardText(_ c: (rank: Int, suit: Int)) -> String { "\(rankText(c.rank))\(suitEmojis[c.suit])" }

// MARK: - 10) ブラックジャック風（ディーラー対戦・チップ）
final class BlackjackViewController: GameBaseViewController {
    private var deck: [(rank: Int, suit: Int)] = []
    private var player: [(rank: Int, suit: Int)] = []
    private var dealer: [(rank: Int, suit: Int)] = []
    private var chips = 100
    private let bet = 10
    private var inHand = false
    private var dealerHidden = true
    private let chipsLabel = UILabel()
    private let dealerLabel = UILabel()
    private let playerLabel = UILabel()
    private var hitBtn: UIButton!
    private var standBtn: UIButton!
    private var dealBtn: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        gameId = "blackjack"
        title = "ブラックジャック風"
        stack.addArrangedSubview(makeLabel("🂡 ブラックジャック風", size: 22, bold: true, align: .center))
        stack.addArrangedSubview(makeLabel("21に近い方が勝ち。22以上はバースト。ディーラーは17以上で止まります。1回の賭けは10チップ。", size: 12, align: .center))
        stack.addArrangedSubview(statusLabel)
        chipsLabel.font = UIFont.boldSystemFont(ofSize: 18)
        chipsLabel.textColor = .yellow
        chipsLabel.textAlignment = .center
        stack.addArrangedSubview(chipsLabel)
        dealerLabel.font = UIFont.systemFont(ofSize: 19)
        dealerLabel.textColor = .white
        dealerLabel.numberOfLines = 0
        stack.addArrangedSubview(dealerLabel)
        playerLabel.font = UIFont.systemFont(ofSize: 19)
        playerLabel.textColor = .white
        playerLabel.numberOfLines = 0
        stack.addArrangedSubview(playerLabel)
        dealBtn = makeButton("🃏 配る（賭け10チップ）", bg: UIColor(red: 0.10, green: 0.55, blue: 0.30, alpha: 1), size: 18)
        dealBtn.addAction(UIAction { [weak self] _ in self?.deal() }, for: .touchUpInside)
        stack.addArrangedSubview(dealBtn)
        hitBtn = makeButton("➕ ヒット（もう1枚）", bg: UIColor(red: 0.85, green: 0.30, blue: 0.10, alpha: 1), size: 18)
        hitBtn.addAction(UIAction { [weak self] _ in self?.hit() }, for: .touchUpInside)
        standBtn = makeButton("✋ スタンド（勝負）", bg: UIColor(red: 0.15, green: 0.45, blue: 0.90, alpha: 1), size: 18)
        standBtn.addAction(UIAction { [weak self] _ in self?.stand() }, for: .touchUpInside)
        stack.addArrangedSubview(equalRow([hitBtn, standBtn]))
        let cashBtn = makeButton("💰 精算して終わる", bg: UIColor.black.withAlphaComponent(0.4))
        cashBtn.addAction(UIAction { [weak self] _ in self?.cashOut() }, for: .touchUpInside)
        stack.addArrangedSubview(cashBtn)
        addRetryHomeRow { [weak self] in self?.resetGame() }
        resetGame()
    }
    private func handValue(_ hand: [(rank: Int, suit: Int)]) -> Int {
        var total = 0
        var aces = 0
        for c in hand {
            if c.rank == 1 { total += 11; aces += 1 }
            else { total += min(c.rank, 10) }
        }
        while total > 21 && aces > 0 { total -= 10; aces -= 1 }
        return total
    }
    private func resetGame() {
        chips = 100
        inHand = false
        player = []; dealer = []
        refresh()
        setStatus("「配る」を押してスタート！")
    }
    private func refresh() {
        chipsLabel.text = "💰 チップ：\(chips)"
        let dText = dealer.isEmpty ? "—" : dealer.enumerated().map { (i, c) in (dealerHidden && i == 1) ? "🂠" : cardText(c) }.joined(separator: " ")
        let dVal = dealer.isEmpty ? "" : (dealerHidden ? "（\(cardText(dealer[0])) の分だけ見える）" : "合計 \(handValue(dealer))")
        dealerLabel.text = "🤖 ディーラー：\(dText) \(dVal)"
        let pText = player.isEmpty ? "—" : player.map { cardText($0) }.joined(separator: " ")
        playerLabel.text = "😀 あなた：\(pText)\(player.isEmpty ? "" : "　合計 \(handValue(player))")"
        hitBtn.isEnabled = inHand
        standBtn.isEnabled = inHand
        dealBtn.isEnabled = !inHand
    }
    private func drawCard() -> (rank: Int, suit: Int) {
        if deck.isEmpty { deck = makeDeck() }
        return deck.removeLast()
    }
    private func deal() {
        if chips < bet {
            finishGame(won: false, playerCount: 1, titleText: "💸 チップが尽きた…",
                       message: "最終チップ：\(chips)") { [weak self] in self?.resetGame() }
            return
        }
        chips -= bet
        deck = makeDeck()
        player = [drawCard(), drawCard()]
        dealer = [drawCard(), drawCard()]
        dealerHidden = true
        inHand = true
        SoundManager.shared.playCard()
        refresh()
        if handValue(player) == 21 {
            setStatus("🎉 ブラックジャック！そのままスタンドがおすすめ")
        } else {
            setStatus("ヒットかスタンドを選んでね")
        }
    }
    private func hit() {
        guard inHand else { return }
        player.append(drawCard())
        SoundManager.shared.playCard()
        refresh()
        let v = handValue(player)
        if v > 21 {
            inHand = false
            refresh()
            setStatus("💥 バースト（\(v)）… 賭け金没収")
            SoundManager.shared.bad()
            afterHand()
        } else if v == 21 {
            stand()
        }
    }
    private func stand() {
        guard inHand else { return }
        inHand = false
        dealerHidden = false
        while handValue(dealer) < 17 { dealer.append(drawCard()) }
        refresh()
        let pv = handValue(player)
        let dv = handValue(dealer)
        if dv > 21 {
            chips += bet * 2
            setStatus("🎉 ディーラーがバースト（\(dv)）！ +\(bet * 2) チップ")
            SoundManager.shared.win()
        } else if pv > dv {
            chips += bet * 2
            setStatus("🎉 あなたの勝ち（\(pv) 対 \(dv)）！ +\(bet * 2) チップ")
            SoundManager.shared.win()
        } else if pv == dv {
            chips += bet
            setStatus("🤝 引き分け（\(pv)）。賭け金が戻った")
        } else {
            setStatus("😢 ディーラーの勝ち（\(pv) 対 \(dv)）…")
            SoundManager.shared.bad()
        }
        refresh()
        afterHand()
    }
    private func afterHand() {
        DataStore.shared.submitScore(gameId: "blackjack", score: chips)
        if chips < bet {
            finishGame(won: false, playerCount: 1, titleText: "💸 チップが尽きた…",
                       message: "チップが賭け金（10）未満になりました") { [weak self] in self?.resetGame() }
        }
    }
    private func cashOut() {
        if inHand { setStatus("対戦中は精算できないよ"); return }
        DataStore.shared.submitScore(gameId: "blackjack", score: chips)
        finishGame(won: chips > 100, playerCount: 1, titleText: "💰 精算",
                   message: "最終チップ：\(chips)（開始100）\(chips > 100 ? "　増えた！" : "")") { [weak self] in self?.resetGame() }
    }
}

// MARK: - 11) ハイ＆ロー（連続正解スコア）
final class HighLowViewController: GameBaseViewController {
    private var deck: [(rank: Int, suit: Int)] = []
    private var current: (rank: Int, suit: Int) = (7, 0)
    private var streak = 0
    private var best = 0
    private var over = false
    private let cardLabel = UILabel()
    private let streakLabel = UILabel()

    override func viewDidLoad() {
        super.viewDidLoad()
        gameId = "highlow"
        title = "ハイ＆ロー"
        stack.addArrangedSubview(makeLabel("⬆️ ハイ＆ロー", size: 22, bold: true, align: .center))
        stack.addArrangedSubview(makeLabel("次のカードが今より「高い」か「低い」か当てる。同点はセーフ（続く）。", size: 12, align: .center))
        stack.addArrangedSubview(statusLabel)
        cardLabel.font = UIFont.boldSystemFont(ofSize: 64)
        cardLabel.textAlignment = .center
        stack.addArrangedSubview(cardLabel)
        streakLabel.font = UIFont.boldSystemFont(ofSize: 18)
        streakLabel.textColor = .yellow
        streakLabel.textAlignment = .center
        stack.addArrangedSubview(streakLabel)
        let highBtn = makeButton("⬆️ 高い", bg: UIColor(red: 0.85, green: 0.30, blue: 0.10, alpha: 1), size: 22)
        highBtn.addAction(UIAction { [weak self] _ in self?.guess(high: true) }, for: .touchUpInside)
        let lowBtn = makeButton("⬇️ 低い", bg: UIColor(red: 0.15, green: 0.45, blue: 0.90, alpha: 1), size: 22)
        lowBtn.addAction(UIAction { [weak self] _ in self?.guess(high: false) }, for: .touchUpInside)
        stack.addArrangedSubview(equalRow([highBtn, lowBtn]))
        addRetryHomeRow { [weak self] in self?.resetGame() }
        resetGame()
    }
    private func resetGame() {
        deck = makeDeck()
        current = deck.removeLast()
        streak = 0
        over = false
        refresh()
        setStatus("次のカードは高い？低い？")
    }
    private func refresh() {
        cardLabel.text = cardText(current)
        streakLabel.text = "🔥 連続正解：\(streak)　（ベスト記録：\(DataStore.shared.best(for: "highlow"))）"
    }
    private func guess(high: Bool) {
        if over { return }
        if deck.isEmpty { deck = makeDeck() }
        let next = deck.removeLast()
        SoundManager.shared.flip()
        if next.rank == current.rank {
            current = next
            refresh()
            setStatus("😌 同点セーフ！ \(cardText(next)) で続行")
            return
        }
        let isHigh = next.rank > current.rank
        current = next
        if isHigh == high {
            streak += 1
            if streak > best { best = streak }
            SoundManager.shared.buy()
            refresh()
            setStatus("🎉 正解！ \(cardText(next))　この調子！")
        } else {
            over = true
            refresh()
            SoundManager.shared.bad()
            DataStore.shared.submitScore(gameId: "highlow", score: streak)
            finishGame(won: streak >= 3, playerCount: 1, titleText: "😢 はずれ…",
                       message: "出たカードは \(cardText(next))。連続正解は \(streak) 回でした") { [weak self] in self?.resetGame() }
        }
    }
}
