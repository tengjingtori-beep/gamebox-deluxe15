import UIKit

// MARK: - スクロール＋縦並びの土台
class ScrollStackViewController: UIViewController {
let scroll = UIScrollView()
let stack = UIStackView()
override func viewDidLoad() {
super.viewDidLoad()
view.backgroundColor = UIColor(red: 0.16, green: 0.10, blue: 0.30, alpha: 1)
scroll.translatesAutoresizingMaskIntoConstraints = false
view.addSubview(scroll)
stack.axis = .vertical
stack.spacing = 12
stack.translatesAutoresizingMaskIntoConstraints = false
scroll.addSubview(stack)
NSLayoutConstraint.activate([
scroll.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
scroll.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
scroll.leadingAnchor.constraint(equalTo: view.leadingAnchor),
scroll.trailingAnchor.constraint(equalTo: view.trailingAnchor),
stack.topAnchor.constraint(equalTo: scroll.topAnchor, constant: 14),
stack.bottomAnchor.constraint(equalTo: scroll.bottomAnchor, constant: -14),
stack.leadingAnchor.constraint(equalTo: scroll.leadingAnchor, constant: 14),
stack.trailingAnchor.constraint(equalTo: scroll.trailingAnchor, constant: -14),
stack.widthAnchor.constraint(equalTo: scroll.widthAnchor, constant: -28),
])
}
}

// MARK: - ゲーム画面の土台（カバー画面・結果・ホーム/リトライ）
class GameBaseViewController: ScrollStackViewController {
let statusLabel = UILabel()
var gameId: String = ""
var recorded = false
private var coverView: UIView?

override func viewDidLoad() {
super.viewDidLoad()
statusLabel.font = UIFont.boldSystemFont(ofSize: 16)
statusLabel.textColor = .white
statusLabel.numberOfLines = 0
statusLabel.backgroundColor = UIColor.black.withAlphaComponent(0.30)
statusLabel.layer.cornerRadius = 8
statusLabel.clipsToBounds = true
}

override func viewDidLayoutSubviews() {
super.viewDidLayoutSubviews()
applyGradient(to: view, top: DataStore.shared.currentTheme.top, bottom: DataStore.shared.currentTheme.bottom)
}

func setStatus(_ s: String) { statusLabel.text = "　" + s}

// パス＆プレイ用：次の人に渡すカバー画面
func showPassCover(playerName: String, completion: @escaping () -> Void) {
hidePassCover()
let v = UIView()
v.backgroundColor = UIColor(red: 0.08, green: 0.06, blue: 0.18, alpha: 0.97)
v.translatesAutoresizingMaskIntoConstraints = false
view.addSubview(v)
NSLayoutConstraint.activate([
v.topAnchor.constraint(equalTo: view.topAnchor), v.bottomAnchor.constraint(equalTo: view.bottomAnchor),
v.leadingAnchor.constraint(equalTo: view.leadingAnchor), v.trailingAnchor.constraint(equalTo: view.trailingAnchor),
])
let inner = UIStackView()
inner.axis = .vertical
inner.spacing = 16
inner.translatesAutoresizingMaskIntoConstraints = false
v.addSubview(inner)
NSLayoutConstraint.activate([
inner.centerYAnchor.constraint(equalTo: v.centerYAnchor),
inner.leadingAnchor.constraint(equalTo: v.leadingAnchor, constant: 24),
inner.trailingAnchor.constraint(equalTo: v.trailingAnchor, constant: -24),
])
inner.addArrangedSubview(makeLabel("📱 スマホを渡してね", size: 22, bold: true, align:.center))
inner.addArrangedSubview(makeLabel(playerName, size: 30, bold: true, color:.yellow, align:.center))
inner.addArrangedSubview(makeLabel("他の人は画面を見ないでね", size: 14, align:.center))
let b = makeButton("準備OK！ はじめる", bg: UIColor(red: 0.85, green: 0.30, blue: 0.10, alpha: 1), size: 20)
b.addAction(UIAction { _ in
SoundManager.shared.click()
self.hidePassCover()
completion()
}, for:.touchUpInside)
inner.addArrangedSubview(b)
coverView = v
}
func hidePassCover() { coverView?.removeFromSuperview(); coverView = nil}

// 結果を表示（記録もここで付ける）
func finishGame(won: Bool, playerCount: Int, titleText: String, message: String, retry: @escaping () -> Void) {
if!recorded {
recorded = true
DataStore.shared.recordPlay(gameId: gameId, playerCount: playerCount, won: won)
if won { SoundManager.shared.win()} else { SoundManager.shared.bad()}
}
let a = UIAlertController(title: titleText, message: message + "\n（コイン：勝利+30／参加+5、実績ボーナスあり）", preferredStyle:.alert)
a.addAction(UIAlertAction(title: "もう一回", style:.default) { _ in
self.recorded = false
retry()
})
a.addAction(UIAlertAction(title: "ホームへ戻る", style:.cancel) { _ in
self.navigationController?.popToRootViewController(animated: true)
})
present(a, animated: true)
}

// 画面下に置く「もう一回／ホームへ戻る」行
func addRetryHomeRow(retry: @escaping () -> Void) {
let row = UIStackView()
row.axis = .horizontal
row.spacing = 10
row.distribution = .fillEqually
let r = makeButton("🔁 もう一回", bg: UIColor(red: 0.10, green: 0.55, blue: 0.30, alpha: 1))
r.addAction(UIAction { _ in self.recorded = false; retry()}, for:.touchUpInside)
let h = makeButton("🏠 ホームへ戻る", bg: UIColor.black.withAlphaComponent(0.4))
h.addAction(UIAction { _ in self.navigationController?.popToRootViewController(animated: true)}, for:.touchUpInside)
row.addArrangedSubview(r)
row.addArrangedSubview(h)
stack.addArrangedSubview(row)
}
}

// 横並び（等幅）の行を作る
func equalRow(_ views: [UIView]) -> UIStackView {
let row = UIStackView()
row.axis = .horizontal
row.spacing = 8
row.distribution = .fillEqually
for v in views { row.addArrangedSubview(v)}
return row
}

// MARK: - 人数選択（パーティーゲーム共通・2〜7人）
final class PlayerSelectViewController: ScrollStackViewController {
private let info: GameInfo
private let onStart: (Int) -> Void
private var count = 4
private let countLabel = UILabel()

init(info: GameInfo, onStart: @escaping (Int) -> Void) {
self.info = info
self.onStart = onStart
super.init(nibName: nil, bundle: nil)
}
required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented")}

override func viewDidLoad() {
super.viewDidLoad()
title = info.title
stack.addArrangedSubview(makeLabel("\(info.icon) \(info.title)", size: 26, bold: true, align:.center))
stack.addArrangedSubview(makeLabel(info.detail, size: 14, align:.center))
stack.addArrangedSubview(makeLabel("👥 何人で遊ぶ？（1台を渡し合うパス＆プレイ）", size: 16, bold: true))
let minus = makeButton("−", bg: UIColor.black.withAlphaComponent(0.4), size: 22)
minus.addAction(UIAction { _ in if self.count > 2 { self.count -= 1}; self.updateLabel()}, for:.touchUpInside)
let plus = makeButton("＋", bg: UIColor.black.withAlphaComponent(0.4), size: 22)
plus.addAction(UIAction { _ in if self.count < 7 { self.count += 1}; self.updateLabel()}, for:.touchUpInside)
countLabel.font = UIFont.boldSystemFont(ofSize: 20)
countLabel.textColor = .yellow
countLabel.textAlignment = .center
stack.addArrangedSubview(equalRow([minus, countLabel, plus]))
updateLabel()
let start = makeButton("▶ スタート！", bg: UIColor(red: 0.85, green: 0.30, blue: 0.10, alpha: 1), size: 22)
start.addAction(UIAction { [weak self] _ in
guard let self = self else { return }
SoundManager.shared.click()
self.onStart(self.count)
}, for:.touchUpInside)
stack.addArrangedSubview(start)
stack.addArrangedSubview(makeLabel("プレイヤー名は「プレイヤー1〜\(7)」で、色とマークで区別します。", size: 12, align:.center))
}
private func updateLabel() { countLabel.text = "\(count) 人"}
override func viewDidLayoutSubviews() {
super.viewDidLayoutSubviews()
applyGradient(to: view, top: DataStore.shared.currentTheme.top, bottom: DataStore.shared.currentTheme.bottom)
}
}

// MARK: - テーマ＆ショップ
final class ThemeShopViewController: ScrollStackViewController {
override func viewDidLoad() {
super.viewDidLoad()
rebuild()
}
override func viewDidLayoutSubviews() {
super.viewDidLayoutSubviews()
applyGradient(to: view, top: DataStore.shared.currentTheme.top, bottom: DataStore.shared.currentTheme.bottom)
}
private func rebuild() {
stack.arrangedSubviews.forEach { $0.removeFromSuperview()}
stack.addArrangedSubview(makeLabel("🪙 コイン：\(DataStore.shared.coins)", size: 17, bold: true, color:.yellow))
stack.addArrangedSubview(makeLabel("テーマを変えると、全部の画面の背景色が変わります。", size: 13))
for t in allThemes {
let owned = DataStore.shared.ownedThemes.contains(t.id)
let using = DataStore.shared.selectedTheme == t.id
let row = UIView()
row.backgroundColor = UIColor.black.withAlphaComponent(0.30)
row.layer.cornerRadius = 12
let inner = UIStackView()
inner.axis = .vertical
inner.spacing = 6
inner.translatesAutoresizingMaskIntoConstraints = false
row.addSubview(inner)
NSLayoutConstraint.activate([
inner.topAnchor.constraint(equalTo: row.topAnchor, constant: 10),
inner.bottomAnchor.constraint(equalTo: row.bottomAnchor, constant: -10),
inner.leadingAnchor.constraint(equalTo: row.leadingAnchor, constant: 12),
inner.trailingAnchor.constraint(equalTo: row.trailingAnchor, constant: -12),
])
inner.addArrangedSubview(makeLabel("\(t.emoji) \(t.name)　\(t.detail)", size: 15, bold: true))
if using {
inner.addArrangedSubview(makeLabel("✅ 使用中", size: 14, color:.yellow))
} else if owned {
let b = makeButton("このテーマにする", bg: UIColor(red: 0.10, green: 0.55, blue: 0.30, alpha: 1))
b.addAction(UIAction { _ in
DataStore.shared.selectedTheme = t.id
SoundManager.shared.buy()
self.rebuild()
}, for:.touchUpInside)
inner.addArrangedSubview(b)
} else if t.premiumYen > 0 {
let b = makeButton("✨ プレミアム ¥\(t.premiumYen)（お試しで解放）", bg: UIColor(red: 0.55, green: 0.25, blue: 0.75, alpha: 1))
b.addAction(UIAction { _ in
let nav = UINavigationController(rootViewController: TrialStoreViewController())
self.present(nav, animated: true)
}, for:.touchUpInside)
inner.addArrangedSubview(b)
} else {
let b = makeButton("🪙 \(t.coinPrice) コインで買う", bg: UIColor(red: 0.85, green: 0.55, blue: 0.10, alpha: 1))
b.addAction(UIAction { _ in
if DataStore.shared.coins >= t.coinPrice {
DataStore.shared.coins -= t.coinPrice
DataStore.shared.ownedThemes.append(t.id)
SoundManager.shared.buy()
self.rebuild()
} else {
let a = UIAlertController(title: "コインが足りません", message: "ゲームで遊ぶとコインがもらえます（勝利30／参加5）", preferredStyle:.alert)
a.addAction(UIAlertAction(title: "OK", style:.default))
self.present(a, animated: true)
}
}, for:.touchUpInside)
inner.addArrangedSubview(b)
}
stack.addArrangedSubview(row)
}
}
}

// MARK: - プレミアムお試し（本当の課金なし）
final class TrialStoreViewController: ScrollStackViewController {
override func viewDidLoad() {
super.viewDidLoad()
title = "プレミアムお試し"
if navigationItem.leftBarButtonItem == nil {
navigationItem.leftBarButtonItem = UIBarButtonItem(title: "閉じる", style:.plain, target: self, action: #selector(closeSelf))
}
rebuild()
}
@objc private func closeSelf() { dismiss(animated: true)}
private func rebuild() {
stack.arrangedSubviews.forEach { $0.removeFromSuperview()}
let banner = makeLabel("⚠️ これは「お試し」画面です。値段は表示だけ。\nボタンを押しても本当のお金は一切かかりません（実際 ¥0）。通信もしません。", size: 14, bold: true, color:.yellow)
banner.backgroundColor = UIColor.black.withAlphaComponent(0.3)
banner.layer.cornerRadius = 8
banner.clipsToBounds = true
stack.addArrangedSubview(banner)
for p in trialProducts {
let owned = DataStore.shared.trialOwned.contains(p.id) && p.id != "coin1000" && p.id != "coin5000"
let row = UIView()
row.backgroundColor = UIColor.black.withAlphaComponent(0.30)
row.layer.cornerRadius = 12
let inner = UIStackView()
inner.axis = .vertical
inner.spacing = 6
inner.translatesAutoresizingMaskIntoConstraints = false
row.addSubview(inner)
NSLayoutConstraint.activate([
inner.topAnchor.constraint(equalTo: row.topAnchor, constant: 10),
inner.bottomAnchor.constraint(equalTo: row.bottomAnchor, constant: -10),
inner.leadingAnchor.constraint(equalTo: row.leadingAnchor, constant: 12),
inner.trailingAnchor.constraint(equalTo: row.trailingAnchor, constant: -12),
])
inner.addArrangedSubview(makeLabel("\(p.icon) \(p.name)　¥\(p.yen)", size: 16, bold: true))
inner.addArrangedSubview(makeLabel(p.detail, size: 13))
if owned {
inner.addArrangedSubview(makeLabel("✅ お試し入手済み", size: 14, color:.yellow))
} else {
let b = makeButton("お試し購入（実際は ¥0）", bg: UIColor(red: 0.55, green: 0.25, blue: 0.75, alpha: 1))
b.addAction(UIAction { _ in
let a = UIAlertController(title: "お試し購入", message: "「\(p.name)」を表示価格 ¥\(p.yen) でお試しします。\n実際のお金は一切かかりません（¥0）。", preferredStyle:.alert)
a.addAction(UIAlertAction(title: "無料でお試しする", style:.default) { _ in
DataStore.shared.grantTrial(p)
SoundManager.shared.buy()
self.rebuild()
})
a.addAction(UIAlertAction(title: "キャンセル", style:.cancel))
self.present(a, animated: true)
}, for:.touchUpInside)
inner.addArrangedSubview(b)
}
stack.addArrangedSubview(row)
}
}
}

// MARK: - 記録・実績
final class StatsViewController: ScrollStackViewController {
override func viewDidLoad() {
super.viewDidLoad()
let d = DataStore.shared
let rate = d.totalPlays > 0? Int(Double(d.totalWins) / Double(d.totalPlays) * 100): 0
stack.addArrangedSubview(makeLabel("📊 記録", size: 20, bold: true))
stack.addArrangedSubview(makeLabel("総プレイ数：\(d.totalPlays) 回\n勝利：\(d.totalWins) 勝（勝率 \(rate)%）\n遊んだゲーム：\(d.playedGameIds.count) / 17 種類\n勝ったゲーム：\(d.wonGameIds.count) / 17 種類\n最大人数プレイ：\(d.maxPartyPlayers) 人\nコイン：🪙 \(d.coins)", size: 15))
stack.addArrangedSubview(makeLabel("🏆 ゲーム別ベスト", size: 20, bold: true))
for g in allGames {
let plays = d.plays(for: g.id)
var bestText = "-"
let b = d.best(for: g.id)
if b > 0 {
if g.id == "reaction" { bestText = "\(b) ミリ秒"}
else if g.id == "mines" { bestText = "クリア \(b) 秒"}
else { bestText = "\(b) 点"}
}
stack.addArrangedSubview(makeLabel("\(g.icon) \(g.title)：\(plays) 回プレイ／ベスト \(bestText)", size: 13))
}
stack.addArrangedSubview(makeLabel("🏅 実績", size: 20, bold: true))
for a in allAchievements {
let claimed = d.claimedAchievements.contains(a.id)
let done = a.check(d)
let mark = claimed? "✅": (done? "🎁 達成済み（コイン自動受取済み）": "⬜")
stack.addArrangedSubview(makeLabel("\(mark) \(a.name)（+\(a.reward)コイン）\n　\(a.detail)", size: 14))
}
}
override func viewDidLayoutSubviews() {
super.viewDidLayoutSubviews()
applyGradient(to: view, top: DataStore.shared.currentTheme.top, bottom: DataStore.shared.currentTheme.bottom)
}
}

// MARK: - あそびかた
final class HowToViewController: ScrollStackViewController {
override func viewDidLoad() {
super.viewDidLoad()
let text = """
スマホを渡し合うパス＆プレイです。番が来たらカバー画面を開けて遊びます。

🎲 サイコロレース：順番にサイコロを振って進みます。止まったマスのイベント（進む／戻る）に注意。先にゴール（30マス）した人が勝ち。
✊ じゃんけん大会：全員が順番に手を選びます（他の人は見ないでね）。勝った手の人全員に1点。先に3点で優勝。CPU補充をONにすると、足りない分をCPUが埋めます。
🃏 神経衰弱：2枚めくって同じ絵なら自分のもの。ペアを一番多く取った人が勝ち。取れたら続けてめくれます。
🔢 数字当て大会：1〜100の秘密の数字を順番に予想。「もっと大きい／小さい」のヒントを頼りに、当てた人が勝ち。
💣 爆弾パス：爆弾を持っている人は早く「パス！」で次の人へ。チクタク音が速くなったら危険。爆発した人は脱落、最後の1人が勝ち。
❓ クイズ大会：順番に4択クイズに答えます。正解で10点。全12問終わって一番高い人が勝ち。


⭕️ ○×ゲーム：3つ並べれば勝ち。CPUは「やさしい／ふつう／つよい」から選べます。2人対戦もOK。
⚫️ リバーシ：相手の石を挟むとひっくり返ります。置ける場所は「・」で表示。置けないときは自動でパス。最後に多い方が勝ち。
🔵 五目並べ：13×13の盤に交互に置いて、先に5つ並べた方が勝ち。CPU対戦／2人対戦。
🂡 ブラックジャック風：カードの合計を21に近づけます。22以上はバースト負け。ディーラーは17以上で止まります。チップが尽きたらおしまい。
⬆️ ハイ＆ロー：今のカードより次が高いか低いかを当てます。当て続けた回数がスコア。同点はセーフ。


🔠 2048風：上下左右ボタン（スワイプも可）で数字を動かし、同じ数字同士をくっつけます。動けなくなったらゲームオーバー。
💥 地雷探し：マスを開けます。数字は周りの地雷の数。「🚩モード」で旗を立てられます。地雷を踏むと負け、地雷以外を全部開けると勝ち。
🐍 スネーク：矢印ボタン（スワイプも可）でヘビを動かし、🍎を食べると長くなります。壁や自分の体に当たると負け。
⚡️ 反射神経：「待って…」のあと緑になったらすぐタップ。早すぎると失格。反応速度（ミリ秒）を競います。
🔨 もぐらたたき：30秒間、出てくる🐹をタップ。たくさんたたいてハイスコアを目指そう。
🎰 スロット：10コイン賭けてスピン。絵柄が3つそろうと大当たり、2つそろうと小当たり。コインはゲーム内だけのものです。

プレミアム商品は全部「お試し」です。値段は表示だけ、本当のお金は一切かかりません（実際¥0）。全部オフラインで遊べます。
"""
stack.addArrangedSubview(makeLabel(text, size: 14))
}
}

// MARK: - 設定
final class SettingsViewController: ScrollStackViewController {
override func viewDidLoad() {
super.viewDidLoad()
stack.addArrangedSubview(makeLabel("⚙️ 設定", size: 20, bold: true))
stack.addArrangedSubview(switchRow(title: "効果音", isOn: DataStore.shared.soundOn) { DataStore.shared.soundOn = $0})
stack.addArrangedSubview(switchRow(title: "BGM", isOn: DataStore.shared.musicOn) {
DataStore.shared.musicOn = $0
if $0 { SoundManager.shared.startMusic()} else { SoundManager.shared.stopMusic()}
})
stack.addArrangedSubview(switchRow(title: "振動", isOn: DataStore.shared.hapticsOn) { DataStore.shared.hapticsOn = $0})
let reset = makeButton("記録を全部消す", bg: UIColor(red: 0.75, green: 0.15, blue: 0.15, alpha: 1))
reset.addTarget(self, action: #selector(resetData), for:.touchUpInside)
stack.addArrangedSubview(reset)
stack.addArrangedSubview(makeLabel("バージョン 1.0 / iPhone 7・iOS 15対応 / 完全オフライン", size: 12, align:.center))
}

private func switchRow(title: String, isOn: Bool, onChange: @escaping (Bool) -> Void) -> UIView {
let row = UIStackView()
row.axis = .horizontal
row.spacing = 8
row.addArrangedSubview(makeLabel(title, size: 16))
let sw = UISwitch()
sw.isOn = isOn
sw.addAction(UIAction { _ in onChange(sw.isOn)}, for:.valueChanged)
row.addArrangedSubview(sw)
return row
}

@objc private func resetData() {
let a = UIAlertController(title: "記録を消しますか？", message: "コイン・記録・実績が全部消えます", preferredStyle:.alert)
a.addAction(UIAlertAction(title: "消す", style:.destructive) { _ in
if let bundle = Bundle.main.bundleIdentifier {
UserDefaults.standard.removePersistentDomain(forName: bundle)
}
self.navigationController?.dismiss(animated: true)
})
a.addAction(UIAlertAction(title: "キャンセル", style:.cancel))
present(a, animated: true)
}
}
