import UIKit

// MARK: - テーマ（背景色）
struct GameTheme: Identifiable {
    let id: String
    let name: String
    let coinPrice: Int
    let premiumYen: Int
    let top: UIColor
    let bottom: UIColor
    let emoji: String
    let detail: String
}

let allThemes: [GameTheme] = [
    GameTheme(id: "violet", name: "バイオレット", coinPrice: 0, premiumYen: 0,
              top: UIColor(red: 0.30, green: 0.15, blue: 0.55, alpha: 1), bottom: UIColor(red: 0.10, green: 0.25, blue: 0.60, alpha: 1),
              emoji: "🎲", detail: "紫〜青の標準テーマ"),
    GameTheme(id: "forest", name: "森", coinPrice: 100, premiumYen: 0,
              top: UIColor(red: 0.05, green: 0.35, blue: 0.18, alpha: 1), bottom: UIColor(red: 0.10, green: 0.55, blue: 0.30, alpha: 1),
              emoji: "🌲", detail: "緑の森"),
    GameTheme(id: "ocean", name: "海", coinPrice: 150, premiumYen: 0,
              top: UIColor(red: 0.05, green: 0.40, blue: 0.70, alpha: 1), bottom: UIColor(red: 0.10, green: 0.65, blue: 0.85, alpha: 1),
              emoji: "🌊", detail: "青い海"),
    GameTheme(id: "sunset", name: "夕焼け", coinPrice: 200, premiumYen: 0,
              top: UIColor(red: 0.90, green: 0.40, blue: 0.20, alpha: 1), bottom: UIColor(red: 0.98, green: 0.70, blue: 0.30, alpha: 1),
              emoji: "🌇", detail: "オレンジの夕方"),
    GameTheme(id: "sakura", name: "桜", coinPrice: 250, premiumYen: 0,
              top: UIColor(red: 0.85, green: 0.45, blue: 0.60, alpha: 1), bottom: UIColor(red: 0.98, green: 0.80, blue: 0.88, alpha: 1),
              emoji: "🌸", detail: "ピンクの和風"),
    GameTheme(id: "night", name: "星空", coinPrice: 300, premiumYen: 0,
              top: UIColor(red: 0.03, green: 0.05, blue: 0.20, alpha: 1), bottom: UIColor(red: 0.20, green: 0.15, blue: 0.45, alpha: 1),
              emoji: "⭐️", detail: "真夜中の星空"),
    GameTheme(id: "gold", name: "ゴールド", coinPrice: 0, premiumYen: 480,
              top: UIColor(red: 0.55, green: 0.40, blue: 0.05, alpha: 1), bottom: UIColor(red: 0.95, green: 0.78, blue: 0.20, alpha: 1),
              emoji: "👑", detail: "プレミアム：金ピカ"),
    GameTheme(id: "rainbow", name: "レインボー", coinPrice: 0, premiumYen: 680,
              top: UIColor(red: 0.60, green: 0.25, blue: 0.85, alpha: 1), bottom: UIColor(red: 0.20, green: 0.75, blue: 0.85, alpha: 1),
              emoji: "🌈", detail: "プレミアム：虹色"),
]

// MARK: - お試し課金アイテム（表示だけ。本当のお金は一切かかりません）
struct TrialProduct: Identifiable {
    let id: String
    let name: String
    let yen: Int
    let detail: String
    let icon: String
}

let trialProducts: [TrialProduct] = [
    TrialProduct(id: "gold", name: "ゴールド テーマ", yen: 480, detail: "金ピカのプレミアムテーマ", icon: "👑"),
    TrialProduct(id: "rainbow", name: "レインボー テーマ", yen: 680, detail: "虹色のプレミアムテーマ", icon: "🌈"),
    TrialProduct(id: "coin1000", name: "コイン 1000枚", yen: 320, detail: "テーマ購入に使えるコイン", icon: "🪙"),
    TrialProduct(id: "coin5000", name: "コイン 5000枚", yen: 980, detail: "コインがどっさり", icon: "💰"),
    TrialProduct(id: "allthemes", name: "全テーマ解放パス", yen: 980, detail: "有料テーマを全部解放", icon: "🔓"),
    TrialProduct(id: "allpack", name: "全部入りパック", yen: 1480, detail: "全テーマ＋コイン5000枚", icon: "🎁"),
]

// MARK: - ゲーム一覧
struct GameInfo {
    let id: String
    let title: String
    let icon: String
    let category: String
    let detail: String
}

let allGames: [GameInfo] = [
    GameInfo(id: "diceRace", title: "サイコロレース", icon: "🎲", category: "party", detail: "すごろく風。順番に振って30マス先のゴールを目指す"),
    GameInfo(id: "janken", title: "じゃんけん大会", icon: "✊", category: "party", detail: "全員でじゃんけん。勝ち抜きで先に3点！"),
    GameInfo(id: "memory", title: "神経衰弱", icon: "🃏", category: "party", detail: "カードのペアを当てる。取ったペア数で勝負"),
    GameInfo(id: "numGuess", title: "数字当て大会", icon: "🔢", category: "party", detail: "1〜100の秘密の数字を順番に当てる"),
    GameInfo(id: "bombPass", title: "爆弾パス", icon: "💣", category: "party", detail: "爆弾を回して、爆発した人が脱落！"),
    GameInfo(id: "quiz", title: "クイズ大会", icon: "❓", category: "party", detail: "オリジナル問題24問。順番に答えてスコア競争"),
    GameInfo(id: "tictactoe", title: "○×ゲーム", icon: "⭕️", category: "battle", detail: "三目並べ。CPUの強さ3段階／2人対戦"),
    GameInfo(id: "reversi", title: "リバーシ", icon: "⚫️", category: "battle", detail: "挟んでひっくり返す。合法手表示・CPU対戦"),
    GameInfo(id: "gomoku", title: "五目並べ", icon: "🔵", category: "battle", detail: "13×13の盤で先に5つ並べる"),
    GameInfo(id: "blackjack", title: "ブラックジャック風", icon: "🂡", category: "battle", detail: "ディーラー対戦。21に近づけてチップを増やす"),
    GameInfo(id: "highlow", title: "ハイ＆ロー", icon: "⬆️", category: "battle", detail: "次のカードが高いか低いか当て続ける"),
    GameInfo(id: "p2048", title: "2048風パズル", icon: "🔠", category: "solo", detail: "同じ数字をくっつけて大きくする"),
    GameInfo(id: "mines", title: "地雷探し", icon: "💥", category: "solo", detail: "9×9・地雷10個。旗モード切り替え付き"),
    GameInfo(id: "snake", title: "スネーク", icon: "🐍", category: "solo", detail: "エサを食べて長くなる。壁と自分に注意"),
    GameInfo(id: "reaction", title: "反射神経", icon: "⚡️", category: "solo", detail: "緑になったら即タップ！何ミリ秒で押せる？"),
    GameInfo(id: "whack", title: "もぐらたたき", icon: "🔨", category: "solo", detail: "30秒で何匹たたける？穴は9つ"),
    GameInfo(id: "slot", title: "スロット", icon: "🎰", category: "solo", detail: "コインを賭けて絵柄をそろえる"),
]

func gameInfo(_ id: String) -> GameInfo { allGames.first { $0.id == id } ?? allGames[0] }
func playerColor(_ i: Int) -> UIColor {
    let cs: [UIColor] = [
        UIColor(red: 0.90, green: 0.25, blue: 0.25, alpha: 1),
        UIColor(red: 0.15, green: 0.45, blue: 0.90, alpha: 1),
        UIColor(red: 0.15, green: 0.65, blue: 0.30, alpha: 1),
        UIColor(red: 0.95, green: 0.60, blue: 0.10, alpha: 1),
        UIColor(red: 0.65, green: 0.30, blue: 0.85, alpha: 1),
        UIColor(red: 0.10, green: 0.65, blue: 0.65, alpha: 1),
        UIColor(red: 0.90, green: 0.40, blue: 0.65, alpha: 1),
    ]
    return cs[i % cs.count]
}
let playerMarks = ["🔴", "🔵", "🟢", "🟠", "🟣", "🟦", "🩷"]

// MARK: - 保存データ（全部オフライン・端末の中だけ）
final class DataStore {
    static let shared = DataStore()
    private let d = UserDefaults.standard

    var coins: Int { get { d.integer(forKey: "coins") } set { d.set(newValue, forKey: "coins") } }
    var ownedThemes: [String] { get { d.stringArray(forKey: "ownedThemes") ?? ["violet"] } set { d.set(newValue, forKey: "ownedThemes") } }
    var selectedTheme: String { get { d.string(forKey: "selectedTheme") ?? "violet" } set { d.set(newValue, forKey: "selectedTheme") } }
    var trialOwned: [String] { get { d.stringArray(forKey: "trialOwned") ?? [] } set { d.set(newValue, forKey: "trialOwned") } }
    var totalPlays: Int { get { d.integer(forKey: "totalPlays") } set { d.set(newValue, forKey: "totalPlays") } }
    var totalWins: Int { get { d.integer(forKey: "totalWins") } set { d.set(newValue, forKey: "totalWins") } }
    var playedGameIds: [String] { get { d.stringArray(forKey: "playedGameIds") ?? [] } set { d.set(newValue, forKey: "playedGameIds") } }
    var wonGameIds: [String] { get { d.stringArray(forKey: "wonGameIds") ?? [] } set { d.set(newValue, forKey: "wonGameIds") } }
    var played7: Bool { get { d.bool(forKey: "played7") } set { d.set(newValue, forKey: "played7") } }
    var maxPartyPlayers: Int { get { d.integer(forKey: "maxPartyPlayers") } set { d.set(newValue, forKey: "maxPartyPlayers") } }
    var claimedAchievements: [String] { get { d.stringArray(forKey: "claimed") ?? [] } set { d.set(newValue, forKey: "claimed") } }
    var soundOn: Bool { get { d.object(forKey: "soundOn") == nil ? true : d.bool(forKey: "soundOn") } set { d.set(newValue, forKey: "soundOn") } }
    var musicOn: Bool { get { d.bool(forKey: "musicOn") } set { d.set(newValue, forKey: "musicOn") } }
    var hapticsOn: Bool { get { d.object(forKey: "hapticsOn") == nil ? true : d.bool(forKey: "hapticsOn") } set { d.set(newValue, forKey: "hapticsOn") } }

    init() {
        if d.object(forKey: "coins") == nil { d.set(300, forKey: "coins") }
        checkDailyBonus()
    }

    var currentTheme: GameTheme { allThemes.first { $0.id == selectedTheme } ?? allThemes[0] }

    private func checkDailyBonus() {
        let f = DateFormatter(); f.dateFormat = "yyyy-MM-dd"
        let today = f.string(from: Date())
        if d.string(forKey: "lastDay") != today {
            d.set(today, forKey: "lastDay")
            coins += 50
            d.set(true, forKey: "dailyBonusReady")
        }
    }
    var dailyBonusReady: Bool { get { d.bool(forKey: "dailyBonusReady") } set { d.set(newValue, forKey: "dailyBonusReady") } }

    // ゲーム別ベストスコア（大きい方が良いもの）
    func best(for gameId: String) -> Int { d.integer(forKey: "best_" + gameId) }
    func submitScore(gameId: String, score: Int, lowerIsBetter: Bool = false) {
        let key = "best_" + gameId
        let cur = d.integer(forKey: key)
        if cur == 0 || (lowerIsBetter ? score < cur : score > cur) { d.set(score, forKey: key) }
    }
    func plays(for gameId: String) -> Int { d.integer(forKey: "plays_" + gameId) }

    func recordPlay(gameId: String, playerCount: Int, won: Bool) {
        totalPlays += 1
        d.set(plays(for: gameId) + 1, forKey: "plays_" + gameId)
        if !playedGameIds.contains(gameId) { playedGameIds.append(gameId) }
        if playerCount >= 7 { played7 = true }
        if playerCount > maxPartyPlayers { maxPartyPlayers = playerCount }
        if won {
            totalWins += 1
            if !wonGameIds.contains(gameId) { wonGameIds.append(gameId) }
            coins += 30
        } else {
            coins += 5
        }
        _ = claimAchievements()
    }

    func grantTrial(_ p: TrialProduct) {
        if !trialOwned.contains(p.id) { trialOwned.append(p.id) }
        switch p.id {
        case "gold":
            if !ownedThemes.contains("gold") { ownedThemes.append("gold") }
        case "rainbow":
            if !ownedThemes.contains("rainbow") { ownedThemes.append("rainbow") }
        case "coin1000":
            coins += 1000
        case "coin5000":
            coins += 5000
        case "allthemes":
            for t in allThemes where !ownedThemes.contains(t.id) { ownedThemes.append(t.id) }
        case "allpack":
            for t in allThemes where !ownedThemes.contains(t.id) { ownedThemes.append(t.id) }
            coins += 5000
            for t in ["gold", "rainbow", "allthemes"] where !trialOwned.contains(t) { trialOwned.append(t) }
        default: break
        }
    }
}

// MARK: - 実績（12個）
struct Achievement: Identifiable {
    let id: String
    let name: String
    let detail: String
    let reward: Int
    let check: (DataStore) -> Bool
}

let allAchievements: [Achievement] = [
    Achievement(id: "play1", name: "はじめの一歩", detail: "はじめてゲームで遊ぶ", reward: 30) { $0.totalPlays >= 1 },
    Achievement(id: "win1", name: "初勝利！", detail: "はじめて1位／勝利する", reward: 50) { $0.totalWins >= 1 },
    Achievement(id: "play20", name: "常連さん", detail: "合計20回遊ぶ", reward: 80) { $0.totalPlays >= 20 },
    Achievement(id: "win10", name: "常勝", detail: "合計10勝する", reward: 150) { $0.totalWins >= 10 },
    Achievement(id: "kinds5", name: "5種制覇（遊ぶ）", detail: "違うゲームを5種類遊ぶ", reward: 100) { $0.playedGameIds.count >= 5 },
    Achievement(id: "kinds10", name: "10種制覇（遊ぶ）", detail: "違うゲームを10種類遊ぶ", reward: 150) { $0.playedGameIds.count >= 10 },
    Achievement(id: "kinds17", name: "全ゲーム制覇（遊ぶ）", detail: "全17種類で遊ぶ", reward: 300) { $0.playedGameIds.count >= 17 },
    Achievement(id: "winkinds5", name: "5種制覇（勝つ）", detail: "5種類のゲームで勝つ", reward: 200) { $0.wonGameIds.count >= 5 },
    Achievement(id: "seven", name: "7人プレイ", detail: "7人でパーティーゲームをする", reward: 80) { $0.played7 },
    Achievement(id: "score2048", name: "2048名人", detail: "2048風で1024点以上", reward: 120) { $0.best(for: "p2048") >= 1024 },
    Achievement(id: "reaction300", name: "神速タップ", detail: "反射神経で300ミリ秒以下", reward: 120) { let b = $0.best(for: "reaction"); return b > 0 && b <= 300 },
    Achievement(id: "rich", name: "コイン持ち", detail: "コインを1000枚以上持つ", reward: 100) { $0.coins >= 1000 },
]

extension DataStore {
    func claimAchievements() -> Int {
        var gained = 0
        for a in allAchievements where a.check(self) && !claimedAchievements.contains(a.id) {
            claimedAchievements.append(a.id)
            coins += a.reward
            gained += a.reward
        }
        return gained
    }
}
